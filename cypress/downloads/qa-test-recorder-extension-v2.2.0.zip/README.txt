# QA Test Recorder - Extensão do Chrome

## Como instalar a extensão:

1. **Extraia o arquivo ZIP baixado** em uma pasta no seu computador
2. **Abra o Google Chrome** e vá para: `chrome://extensions/`
3. **Ative o "Modo do desenvolvedor"** no canto superior direito da página
4. **Clique em "Carregar sem compactação"** (ou "Load unpacked")
5. **Selecione a pasta** onde você extraiu os arquivos da extensão
6. A extensão será instalada e aparecerá na lista de extensões

## Como usar:

1. **Clique no ícone da extensão** na barra de ferramentas do Chrome (pode estar oculto no menu de extensões)
2. **Faça login** com suas credenciais do portal QA Test Recorder
3. **Navegue até a página** que você quer testar
4. **Clique em "Iniciar Gravação"** na extensão
5. **Realize as ações** que você quer gravar (cliques, digitação, etc.)
6. **Pare a gravação** e exporte o teste no formato desejado

## Funcionalidades:

- ✅ **Autenticação segura** com o portal QA Test Recorder
- ✅ **Gravação automática** de ações do usuário
- ✅ **Exportação para múltiplos formatos:**
  - Cypress (JavaScript)
  - Playwright (JavaScript/TypeScript)
  - Robot Framework
  - Selenium Python
- ✅ **Modo de assertions** para verificações automáticas
- ✅ **Interface responsiva** e fácil de usar
- ✅ **Controle de acesso** baseado em planos de assinatura
- ✅ **Portal de configurações** integrado (qa-recorder.com)

## Estrutura dos arquivos:

- **manifest.json** - Configurações da extensão
- **background.js** - Script de background da extensão
- **content.js/css** - Scripts injetados nas páginas web
- **popup.html/js** - Interface do popup principal
- **sidepanel.html/js** - Interface do painel lateral
- **recorder/** - Módulos de gravação e geração de testes
- **sidepanel/** - Módulos do painel lateral e autenticação
- **sidepanel/auth/** - Sistema de autenticação
- **sidepanel/ui/** - Componentes de interface
- **sidepanel/steps/** - Módulos de gerenciamento de passos (refatorado)
- **popup/** - Módulos do popup
- **icons/** - Ícones da extensão (16px, 48px, 128px)

## Portal de configurações:

Acesse **qa-recorder.com** para:
- ✅ Gerenciar sua assinatura
- ✅ Visualizar uso e estatísticas
- ✅ Configurar preferências
- ✅ Suporte técnico

## Requisitos:

- ✅ **Google Chrome** versão 88 ou superior
- ✅ **Conta ativa** no portal QA Test Recorder
- ✅ **Plano válido** (gratuito, mensal ou permanente)

## Troubleshooting:

**Extensão não aparece após instalação:**
- Verifique se o "Modo do desenvolvedor" está ativado
- Recarregue a página de extensões (F5)
- Verifique se todos os arquivos foram extraídos corretamente
- Certifique-se de que selecionou a pasta correta (deve conter o manifest.json)

**Erro de login:**
- Verifique suas credenciais no portal web (qa-recorder.com)
- Certifique-se de que sua assinatura está ativa
- Limpe o cache do navegador se necessário
- Verifique sua conexão com a internet

**Gravação não funciona:**
- Verifique se a extensão tem permissões para a página atual
- Recarregue a página e tente novamente
- Verifique se não há outras extensões conflitantes
- Certifique-se de que clicou em "Iniciar Gravação"

**Sidepanel não abre:**
- Clique no ícone da extensão na barra de ferramentas
- Se não aparecer, procure no menu de extensões (ícone de quebra-cabeça)
- Verifique se a extensão está habilitada em chrome://extensions/

**Configurações e portal:**
- Clique no botão ⚙️ (engrenagem) na extensão
- Acesse qa-recorder.com para configurações avançadas
- Gerencie sua assinatura diretamente no portal

## Recursos Premium:

- **Plano Gratuito (7 dias):** Teste todas as funcionalidades
- **Plano Mensal:** Acesso completo por 30 dias
- **Plano Permanente:** Acesso vitalício a todas as funcionalidades

## Suporte:

Em caso de problemas:
1. Acesse o portal QA Test Recorder (qa-recorder.com)
2. Verifique o status da sua assinatura
3. Entre em contato com o suporte através do portal

---

**Versão:** 2.2.0
**Última atualização:** 11/07/2025
**Compatibilidade:** Chrome 88+
**Portal oficial:** qa-recorder.com
**Arquitetura:** Modular refatorada para melhor manutenibilidade
