// Sistema de Autenticação Simplificado
class SimpleAuth {
  constructor() {
    console.log('🔐 SimpleAuth: Inicializando sistema simples de autenticação');
    this.apiKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Indna3F1YmV5cnlueWd6a3ZvZXpxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg1NDE4MTYsImV4cCI6MjA2NDExNzgxNn0.9flFhZO9h7eeEUctnivmZwkAlLEKctlqleXnBMgoIco';
    this.baseUrl = 'https://wgkqubeyrynygzkvoezq.supabase.co';
    this.isLoggedIn = false;
    this.recorder = null;
    
    this.setupLoginForm();
    this.checkAuthStatus();
    this.setupVisibilityListener();
    this.setupSettingsButtons();
  }

  setupSettingsButtons() {
    // Criar botão de configurações para a tela de login
    this.createLoginSettingsButton();
    
    // Criar botão de configurações para a interface do recorder
    this.createRecorderSettingsButton();
  }

  createLoginSettingsButton() {
    const loginInterface = document.getElementById('loginInterface');
    if (!loginInterface) return;

    // Verificar se já existe o botão
    if (loginInterface.querySelector('.settings-button')) return;

    const settingsButton = document.createElement('button');
    settingsButton.className = 'settings-button';
    settingsButton.innerHTML = '⚙️';
    settingsButton.title = 'Configurações - Gerenciar Plano';
    settingsButton.style.cssText = `
      position: absolute;
      top: 20px;
      right: 20px;
      background: rgba(255, 255, 255, 0.9);
      border: 1px solid #e1e5e9;
      border-radius: 50%;
      width: 40px;
      height: 40px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      transition: all 0.3s ease;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      z-index: 1000;
    `;

    settingsButton.addEventListener('mouseenter', () => {
      settingsButton.style.background = 'rgba(255, 255, 255, 1)';
      settingsButton.style.transform = 'scale(1.1)';
    });

    settingsButton.addEventListener('mouseleave', () => {
      settingsButton.style.background = 'rgba(255, 255, 255, 0.9)';
      settingsButton.style.transform = 'scale(1)';
    });

    settingsButton.addEventListener('click', () => {
      this.openPortalSettings();
    });

    loginInterface.appendChild(settingsButton);
  }

  createRecorderSettingsButton() {
    const recorderInterface = document.getElementById('recorderInterface');
    if (!recorderInterface) return;

    // Verificar se já existe o botão
    if (recorderInterface.querySelector('.recorder-settings-button')) return;

    const header = recorderInterface.querySelector('.header');
    if (!header) return;

    const settingsButton = document.createElement('button');
    settingsButton.className = 'recorder-settings-button';
    settingsButton.innerHTML = '⚙️';
    settingsButton.title = 'Configurações - Gerenciar Plano';
    settingsButton.style.cssText = `
      background: rgba(255, 255, 255, 0.2);
      color: white;
      border: 1px solid rgba(255, 255, 255, 0.3);
      border-radius: 6px;
      padding: 8px 12px;
      cursor: pointer;
      font-size: 14px;
      margin-left: 10px;
      transition: all 0.3s ease;
    `;

    settingsButton.addEventListener('mouseenter', () => {
      settingsButton.style.background = 'rgba(255, 255, 255, 0.3)';
    });

    settingsButton.addEventListener('mouseleave', () => {
      settingsButton.style.background = 'rgba(255, 255, 255, 0.2)';
    });

    settingsButton.addEventListener('click', () => {
      this.openPortalSettings();
    });

    // Adicionar o botão ao lado do botão de logout
    const logoutButton = header.querySelector('#logoutButton');
    if (logoutButton) {
      header.insertBefore(settingsButton, logoutButton);
    } else {
      header.appendChild(settingsButton);
    }
  }

  openPortalSettings() {
    // Abrir o portal em uma nova aba
    const portalUrl = 'https://qa-recorder.com/';
    chrome.tabs.create({ url: portalUrl });
  }

  setupVisibilityListener() {
    // Listen for when the sidepanel becomes visible again
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && this.isLoggedIn) {
        // Refresh the recorder state when sidepanel becomes visible
        this.refreshRecorderState();
      }
    });

    // Listen for focus events
    window.addEventListener('focus', () => {
      if (this.isLoggedIn) {
        this.refreshRecorderState();
      }
    });
  }

  async refreshRecorderState() {
    if (this.recorder) {
      try {
        await this.recorder.loadState();
        console.log('🔄 Estado do gravador atualizado');
      } catch (error) {
        console.error('Erro ao atualizar estado:', error);
      }
    }
  }

  setupLoginForm() {
    const loginForm = document.getElementById('loginForm');
    const passwordToggle = document.getElementById('passwordToggle');
    const passwordInput = document.getElementById('password');

    // Toggle de senha
    if (passwordToggle && passwordInput) {
      passwordToggle.addEventListener('click', () => {
        const type = passwordInput.type === 'password' ? 'text' : 'password';
        passwordInput.type = type;
        passwordToggle.textContent = type === 'password' ? '👁️' : '🙈';
      });
    }

    // Submit do formulário
    if (loginForm) {
      loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleLogin();
      });
    }

    // Logout
    const logoutButton = document.getElementById('logoutButton');
    if (logoutButton) {
      logoutButton.addEventListener('click', () => {
        this.handleLogout();
      });
    }
  }

  async checkAuthStatus() {
    try {
      const result = await chrome.storage.local.get(['supabaseSession', 'isLoggedIn']);
      
      if (result.supabaseSession?.access_token && result.isLoggedIn) {
        console.log('✅ Usuário já está logado');
        this.showRecorderInterface();
      } else {
        console.log('❌ Usuário não está logado');
        this.showLoginInterface();
      }
    } catch (error) {
      console.error('Erro ao verificar status:', error);
      this.showLoginInterface();
    }
  }

  async handleLogin() {
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const loginButton = document.getElementById('loginButton');

    if (!email || !password) {
      this.showMessage('Por favor, preencha email e senha.', 'error');
      return;
    }

    loginButton.disabled = true;
    loginButton.textContent = 'Entrando...';

    try {
      console.log('🚀 Fazendo login...');
      
      // Fazer login
      const response = await fetch(`${this.baseUrl}/auth/v1/token?grant_type=password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': this.apiKey
        },
        body: JSON.stringify({ email, password })
      });

      if (!response.ok) {
        throw new Error('Email ou senha inválidos');
      }

      const loginData = await response.json();

      // Verificar permissões
      const roleResponse = await fetch(`${this.baseUrl}/functions/v1/track-generation`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${loginData.access_token}`,
        },
        body: JSON.stringify({ action: 'check-limit' })
      });

      if (!roleResponse.ok) {
        throw new Error('Não foi possível verificar suas permissões');
      }

      const roleData = await roleResponse.json();

      if (!roleData.canGenerate) {
        throw new Error('Acesso negado. Verifique seu plano.');
      }

      // Salvar dados
      await chrome.storage.local.set({
        supabaseSession: {
          access_token: loginData.access_token,
          refresh_token: loginData.refresh_token,
          user: loginData.user
        },
        userRole: roleData.userRole,
        isLoggedIn: true
      });

      console.log('✅ Login realizado com sucesso!');
      this.showMessage('Login realizado com sucesso!', 'success');
      this.showRecorderInterface();

    } catch (error) {
      console.error('❌ Erro no login:', error);
      this.showMessage(error.message, 'error');
    } finally {
      loginButton.disabled = false;
      loginButton.textContent = 'Entrar na Extensão';
    }
  }

  async handleLogout() {
    try {
      await chrome.storage.local.clear();
      this.isLoggedIn = false;
      this.recorder = null;
      this.showLoginInterface();
      this.showMessage('Logout realizado com sucesso!', 'success');
    } catch (error) {
      console.error('Erro no logout:', error);
    }
  }

  showLoginInterface() {
    const loginInterface = document.getElementById('loginInterface');
    const recorderInterface = document.getElementById('recorderInterface');
    
    if (loginInterface) {
      loginInterface.style.display = 'flex';
      loginInterface.style.visibility = 'visible';
      loginInterface.style.opacity = '1';
    }
    
    if (recorderInterface) {
      recorderInterface.style.display = 'none';
      recorderInterface.style.visibility = 'hidden';
      recorderInterface.style.opacity = '0';
    }

    this.clearLoginForm();
    
    // Criar botão de configurações após mostrar a interface
    setTimeout(() => {
      this.createLoginSettingsButton();
    }, 100);
  }

  showRecorderInterface() {
    const loginInterface = document.getElementById('loginInterface');
    const recorderInterface = document.getElementById('recorderInterface');
    
    if (loginInterface) {
      loginInterface.style.display = 'none';
      loginInterface.style.visibility = 'hidden';
      loginInterface.style.opacity = '0';
    }
    
    if (recorderInterface) {
      recorderInterface.style.display = 'flex';
      recorderInterface.style.visibility = 'visible';
      recorderInterface.style.opacity = '1';
    }

    this.isLoggedIn = true;
    console.log('🎬 Interface de gravação exibida');
    
    // Inicializar o gravador após mostrar a interface
    setTimeout(() => {
      this.initializeRecorder();
      this.createRecorderSettingsButton();
    }, 100);
  }

  initializeRecorder() {
    // Verificar se a classe RecorderMain existe antes de instanciar
    if (typeof RecorderMain !== 'undefined') {
      if (!this.recorder) {
        console.log('🚀 Inicializando gravador...');
        this.recorder = new RecorderMain();
        console.log('✅ Gravador inicializado com sucesso!');
      } else {
        // Refresh existing recorder
        this.recorder.loadState();
      }
    } else {
      console.error('❌ RecorderMain não está definido. Carregando módulos...');
      this.loadRecorderModules().then(() => {
        this.initializeRecorder();
      });
    }
  }

  async loadRecorderModules() {
    try {
      // Carregar módulos do gravador se não estiverem carregados
      await this.loadScript('sidepanel/steps/StepValidator.js');
      await this.loadScript('sidepanel/steps/StepStorage.js');
      await this.loadScript('sidepanel/steps/StepRenderer.js');
      await this.loadScript('sidepanel/steps/RecorderSteps.js');
      await this.loadScript('sidepanel/RecorderMain.js');
      console.log('✅ Módulos do gravador carregados');
    } catch (error) {
      console.error('❌ Erro ao carregar módulos do gravador:', error);
    }
  }

  loadScript(src) {
    return new Promise((resolve, reject) => {
      // Verificar se o script já foi carregado
      if (document.querySelector(`script[src="${src}"]`)) {
        resolve();
        return;
      }
      
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
  }

  showMessage(message, type) {
    const messageContainer = document.getElementById('messageContainer');
    if (!messageContainer) return;

    messageContainer.innerHTML = '';
    
    const messageDiv = document.createElement('div');
    messageDiv.className = type === 'success' ? 'success-message' : 'error-message';
    messageDiv.textContent = message;
    
    messageContainer.appendChild(messageDiv);
    
    setTimeout(() => {
      messageContainer.innerHTML = '';
    }, 3000);
  }

  clearLoginForm() {
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    if (emailInput) emailInput.value = '';
    if (passwordInput) passwordInput.value = '';
  }
}

// Função para carregar scripts dinamicamente
function loadScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

// Inicializar quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', async () => {
  console.log('🚀 Inicializando SimpleAuth...');
  
  try {
    // Carregar módulos do gravador
    await loadScript('sidepanel/RecorderSteps.js');
    await loadScript('sidepanel/RecorderMain.js');
    
    // Inicializar autenticação
    new SimpleAuth();
  } catch (error) {
    console.error('Erro ao carregar módulos:', error);
    new SimpleAuth();
  }
});
