
class SidepanelRecorder {
  constructor(stepsManager) {
    this.stepsManager = stepsManager;
    this.isRecording = false;
    this.assertMode = false;
  }

  async loadState() {
    try {
      const result = await chrome.storage.local.get(['isRecording', 'assertMode', 'steps']);
      
      this.isRecording = result.isRecording || false;
      this.assertMode = result.assertMode || false;
      this.stepsManager.steps = result.steps || [];

      this.updateUI();
      this.stepsManager.renderSteps();
    } catch (error) {
      console.error('Error loading state:', error);
    }
  }

  async saveState() {
    try {
      await chrome.storage.local.set({
        isRecording: this.isRecording,
        assertMode: this.assertMode,
        steps: this.stepsManager.steps
      });
    } catch (error) {
      console.error('Error saving state:', error);
    }
  }

  async toggleRecording() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (this.isRecording) {
        await chrome.tabs.sendMessage(tab.id, { 
          type: 'stopRecording' 
        });
        this.isRecording = false;
        this.updateUI();
      } else {
        await chrome.tabs.sendMessage(tab.id, { 
          type: 'startRecording',
          assertMode: this.assertMode
        });
        this.isRecording = true;
        this.updateUI();
      }
      
      await this.saveState();
    } catch (error) {
      console.error('Error toggling recording:', error);
      this.showError('Erro ao alterar gravação. Recarregue a página e tente novamente.');
    }
  }

  async toggleAssertMode() {
    this.assertMode = !this.assertMode;
    this.assertToggle.classList.toggle('active', this.assertMode);
    
    if (this.isRecording) {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.tabs.sendMessage(tab.id, { 
          type: 'updateAssertMode',
          assertMode: this.assertMode
        });
      } catch (error) {
        console.error('Error updating assert mode:', error);
      }
    }
    
    await this.saveState();
  }

  updateUI() {
    if (this.isRecording) {
      this.recordButton.className = 'record-button stop';
      this.recordIcon.textContent = '⏹️';
      this.recordText.textContent = 'Parar Gravação';
      this.status.className = 'status recording';
      this.status.textContent = 'Status: Gravando...';
    } else {
      this.recordButton.className = 'record-button start';
      this.recordIcon.textContent = '⏺️';
      this.recordText.textContent = 'Iniciar Gravação';
      this.status.className = 'status stopped';
      this.status.textContent = 'Status: Parado';
    }

    this.assertToggle.classList.toggle('active', this.assertMode);
    this.stepsManager.updateStepsCounter();
  }

  showError(message) {
    alert(message);
  }

  initializeElements() {
    this.recordButton = document.getElementById('recordButton');
    this.recordIcon = document.getElementById('recordIcon');
    this.recordText = document.getElementById('recordText');
    this.status = document.getElementById('status');
    this.assertToggle = document.getElementById('assertToggle');
    this.exportCypress = document.getElementById('exportCypress');
    this.exportPlaywright = document.getElementById('exportPlaywright');
  }
}
