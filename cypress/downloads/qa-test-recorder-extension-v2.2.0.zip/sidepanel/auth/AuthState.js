
// Authentication State Manager - Handles flags and state tracking
class AuthState {
  constructor() {
    console.log('🏗️ AuthState: Construtor iniciado');
    this.initialCheck = true; // Flag para controlar primeira verificação
    this.isAuthenticating = false; // Flag para evitar verificações durante login
    this.loginCompleted = false; // Flag para indicar login concluído
    this.authenticationInProgress = false; // Flag para evitar múltiplas verificações
  }

  setInitialCheck(value) {
    console.log('🏁 AuthState: setInitialCheck:', value);
    this.initialCheck = value;
  }

  setAuthenticating(value) {
    console.log('🔄 AuthState: setAuthenticating:', value);
    this.isAuthenticating = value;
  }

  setLoginCompleted(value) {
    console.log('✅ AuthState: setLoginCompleted:', value);
    this.loginCompleted = value;
    
    // Se login foi completado, evitar verificações futuras por um tempo
    if (value === true) {
      this.authenticationInProgress = true;
      // Só permitir nova verificação após 10 segundos
      setTimeout(() => {
        this.authenticationInProgress = false;
        console.log('⏰ AuthState: Liberando verificações futuras');
      }, 10000);
    }
  }

  resetState() {
    console.log('🔄 AuthState: Resetando estado');
    this.initialCheck = true;
    this.isAuthenticating = false;
    this.loginCompleted = false;
    this.authenticationInProgress = false;
  }

  shouldSkipCheck() {
    const skip = this.isAuthenticating || this.loginCompleted || this.authenticationInProgress;
    console.log('🚫 AuthState: shouldSkipCheck:', skip, {
      isAuthenticating: this.isAuthenticating,
      loginCompleted: this.loginCompleted,
      authenticationInProgress: this.authenticationInProgress
    });
    return skip;
  }

  isFirstCheck() {
    return this.initialCheck;
  }

  canProceedWithAuth() {
    const canProceed = !this.isAuthenticating && !this.loginCompleted && !this.authenticationInProgress;
    console.log('🟢 AuthState: canProceedWithAuth:', canProceed);
    return canProceed;
  }

  logCurrentState() {
    console.log('📊 AuthState: Estado atual:', {
      initialCheck: this.initialCheck,
      isAuthenticating: this.isAuthenticating,
      loginCompleted: this.loginCompleted,
      authenticationInProgress: this.authenticationInProgress
    });
  }
}
