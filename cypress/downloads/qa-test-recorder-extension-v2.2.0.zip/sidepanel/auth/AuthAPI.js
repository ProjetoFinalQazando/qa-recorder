
// Authentication API Manager - Handles all API calls
class AuthAPI {
  constructor() {
    this.apiKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Indna3F1YmV5cnlueWd6a3ZvZXpxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg1NDE4MTYsImV4cCI6MjA2NDExNzgxNn0.9flFhZO9h7eeEUctnivmZwkAlLEKctlqleXnBMgoIco';
    this.baseUrl = 'https://wgkqubeyrynygzkvoezq.supabase.co';
  }

  async login(email, password) {
    console.log('🚀 AuthAPI: Tentando fazer login com:', { email });

    const response = await fetch(`${this.baseUrl}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': this.apiKey
      },
      body: JSON.stringify({
        email: email,
        password: password
      })
    });

    console.log('📡 AuthAPI: Status da resposta de login:', response.status);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error('❌ AuthAPI: Login falhou com status:', response.status, 'Resposta:', errorText);
      throw new Error('Email ou senha inválidos.');
    }

    return await response.json();
  }

  async checkUserRole(accessToken) {
    console.log('✅ AuthAPI: Login bem-sucedido, verificando permissões...');

    const response = await fetch(`${this.baseUrl}/functions/v1/track-generation`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${accessToken}`,
      },
      body: JSON.stringify({ action: 'check-limit' })
    });

    if (!response.ok) {
      console.error('❌ AuthAPI: Verificação de role falhou:', response.status);
      throw new Error('Não foi possível verificar suas permissões.');
    }

    const roleData = await response.json();
    console.log('👤 AuthAPI: Dados do role do usuário:', roleData);
    
    return roleData;
  }

  validateUserAccess(roleData) {
    if (!roleData.canGenerate) {
      let message = '';
      if (roleData.userRole === 'free') {
        message = 'Seu período de teste gratuito expirou. Faça upgrade para continuar.';
      } else if (roleData.userRole === 'mensal') {
        message = 'Sua assinatura expirou. Renove seu plano para continuar.';
      } else {
        message = 'Acesso negado. Verifique seu plano.';
      }
      console.log('❌ AuthAPI: Acesso negado:', message);
      throw new Error(message);
    }
  }
}
