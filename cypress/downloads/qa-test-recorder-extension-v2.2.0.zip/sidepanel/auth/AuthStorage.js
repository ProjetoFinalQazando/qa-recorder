
// Authentication Storage Manager - Handles all storage operations
class AuthStorage {
  constructor() {
    console.log('📦 AuthStorage: Construtor iniciado');
  }

  async getStoredSession() {
    try {
      const result = await chrome.storage.local.get(['supabaseSession', 'isLoggedIn']);
      
      console.log('📊 AuthStorage: Dados recuperados do storage:', {
        hasSession: !!result.supabaseSession,
        hasToken: !!result.supabaseSession?.access_token,
        isLoggedIn: result.isLoggedIn
      });

      return result;
    } catch (error) {
      console.error('💥 AuthStorage: Erro ao recuperar dados do storage:', error);
      return {};
    }
  }

  async saveSession(sessionData, userRole) {
    try {
      console.log('💾 AuthStorage: Salvando dados da sessão...');
      
      await chrome.storage.local.set({
        supabaseSession: {
          access_token: sessionData.access_token,
          refresh_token: sessionData.refresh_token,
          user: sessionData.user
        },
        userRole: userRole,
        isLoggedIn: true
      });

      console.log('✅ AuthStorage: Dados salvos com sucesso');
    } catch (error) {
      console.error('💥 AuthStorage: Erro ao salvar dados:', error);
      throw error;
    }
  }

  async clearAllData() {
    try {
      console.log('🗑️ AuthStorage: Limpando todos os dados...');
      await chrome.storage.local.clear();
      console.log('✅ AuthStorage: Dados limpos com sucesso');
    } catch (error) {
      console.error('💥 AuthStorage: Erro ao limpar dados:', error);
      throw error;
    }
  }

  setupStorageListener(callback, authState) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && (changes.supabaseSession || changes.isLoggedIn)) {
        if (!authState.isFirstCheck() && authState.canProceedWithAuth()) {
          console.log('🔄 AuthStorage: Estado de autenticação mudou, reinicializando...', changes);
          setTimeout(() => {
            callback();
          }, 200);
        } else {
          console.log('🚫 AuthStorage: Ignorando mudança de storage');
          authState.logCurrentState();
        }
      }
    });
  }

  hasValidSession(sessionData) {
    return sessionData.supabaseSession?.access_token && sessionData.isLoggedIn;
  }
}
