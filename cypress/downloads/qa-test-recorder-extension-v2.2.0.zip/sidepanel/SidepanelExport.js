
class SidepanelExport {
  constructor(stepsManager, authManager) {
    this.stepsManager = stepsManager;
    this.authManager = authManager;
  }

  async exportTest(framework) {
    console.log('🚀 SIDEPANEL EXPORT TEST INICIADO:', framework);
    console.log('📊 SIDEPANEL STEPS DISPONÍVEIS:', this.stepsManager.steps.length);
    console.log('🔍 SIDEPANEL STEPS DETALHADOS:', this.stepsManager.steps);

    if (this.stepsManager.steps.length === 0) {
      alert('Nenhum passo foi gravado ainda!');
      return;
    }

    await this.authManager.checkUserAccess();
    
    if (!this.authManager.canGenerate) {
      alert('Acesso negado! Verifique seu plano ou período de teste.');
      return;
    }

    await this.authManager.recordGeneration(framework, this.stepsManager.steps.length);

    console.log('🛠️ SIDEPANEL GERANDO CÓDIGO PARA:', framework);
    
    let testCode;
    switch (framework) {
      case 'cypress':
        testCode = this.generateCypressTest();
        break;
      case 'playwright':
        testCode = this.generatePlaywrightTest();
        break;
      case 'robot':
        testCode = this.generateRobotTest();
        break;
      case 'selenium':
        testCode = this.generateSeleniumTest();
        break;
      default:
        testCode = this.generateCypressTest();
    }

    console.log('✅ SIDEPANEL CÓDIGO GERADO:', testCode);
    this.downloadFile(`test.${this.getFileExtension(framework)}`, testCode);
  }

  getFileExtension(framework) {
    const extensions = {
      cypress: 'cy.js',
      playwright: 'spec.js',
      robot: 'robot',
      selenium: 'py'
    };
    return extensions[framework] || 'js';
  }

  generateCypressTest() {
    console.log('🎯 SIDEPANEL GERANDO CYPRESS TEST...');
    
    let code = `describe('Teste Automatizado', () => {
  it('Executa passos gravados', () => {\n`;

    this.stepsManager.steps.forEach((step, index) => {
      console.log(`🔄 SIDEPANEL Processando step ${index + 1}:`, step);
      
      switch (step.type) {
        case 'navigate':
          code += `    cy.visit('${step.url}');\n`;
          break;
        case 'click':
          if (step.selector) {
            code += `    cy.get('${step.selector}').click();\n`;
          } else if (step.text) {
            code += `    cy.contains('${step.text}').click();\n`;
          } else if (step.element) {
            code += `    cy.contains('${step.element}').click();\n`;
          } else {
            code += `    cy.get('button').click();\n`;
          }
          break;
        case 'type':
          if (step.selector && step.text) {
            code += `    cy.get('${step.selector}').clear().type('${step.text}');\n`;
          } else if (step.text) {
            code += `    cy.get('input').type('${step.text}');\n`;
          }
          break;
        case 'scroll':
          if (step.direction === 'top') {
            code += `    cy.scrollTo('top');\n`;
          } else {
            code += `    cy.scrollTo('bottom');\n`;
          }
          break;
        case 'assert':
          if (step.selector) {
            code += `    cy.get('${step.selector}').should('exist');\n`;
          } else if (step.text) {
            code += `    cy.contains('${step.text}').should('be.visible');\n`;
          } else {
            code += `    cy.get('body').should('exist');\n`;
          }
          break;
      }
    });

    code += `  });
});`;

    console.log('✅ SIDEPANEL CYPRESS CODE GERADO:', code);
    return code;
  }

  generatePlaywrightTest() {
    console.log('🎭 SIDEPANEL GERANDO PLAYWRIGHT TEST...');
    
    let code = `const { test, expect } = require('@playwright/test');

test('Teste Automatizado', async ({ page }) => {\n`;

    this.stepsManager.steps.forEach((step, index) => {
      console.log(`🔄 SIDEPANEL Processando step ${index + 1}:`, step);
      
      switch (step.type) {
        case 'navigate':
          code += `  await page.goto('${step.url}');\n`;
          break;
        case 'click':
          if (step.selector) {
            code += `  await page.click('${step.selector}');\n`;
          } else if (step.text) {
            code += `  await page.getByText('${step.text}').click();\n`;
          } else if (step.element) {
            code += `  await page.getByText('${step.element}').click();\n`;
          } else {
            code += `  await page.click('button');\n`;
          }
          break;
        case 'type':
          if (step.selector && step.text) {
            code += `  await page.fill('${step.selector}', '${step.text}');\n`;
          } else if (step.text) {
            code += `  await page.fill('input', '${step.text}');\n`;
          }
          break;
        case 'scroll':
          if (step.direction === 'top') {
            code += `  await page.evaluate(() => window.scrollTo(0, 0));\n`;
          } else {
            code += `  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));\n`;
          }
          break;
        case 'assert':
          if (step.selector) {
            code += `  await expect(page.locator('${step.selector}')).toBeVisible();\n`;
          } else if (step.text) {
            code += `  await expect(page.getByText('${step.text}')).toBeVisible();\n`;
          } else {
            code += `  await expect(page.locator('body')).toBeVisible();\n`;
          }
          break;
      }
    });

    code += `});`;

    console.log('✅ SIDEPANEL PLAYWRIGHT CODE GERADO:', code);
    return code;
  }

  generateRobotTest() {
    console.log('🤖 SIDEPANEL GERANDO ROBOT TEST...');
    
    let code = `*** Settings ***
Library    SeleniumLibrary

*** Test Cases ***
Teste Automatizado
    [Documentation]    Executa passos gravados\n`;

    this.stepsManager.steps.forEach((step, index) => {
      console.log(`🔄 SIDEPANEL Processando step ${index + 1}:`, step);
      
      switch (step.type) {
        case 'navigate':
          code += `    Go To    ${step.url}\n`;
          break;
        case 'click':
          if (step.selector) {
            code += `    Click Element    ${step.selector}\n`;
          } else if (step.text) {
            code += `    Click Element    xpath=//*[contains(text(), '${step.text}')]\n`;
          } else if (step.element) {
            code += `    Click Element    xpath=//*[contains(text(), '${step.element}')]\n`;
          } else {
            code += `    Click Element    tag:button\n`;
          }
          break;
        case 'type':
          if (step.selector && step.text) {
            code += `    Input Text    ${step.selector}    ${step.text}\n`;
          } else if (step.text) {
            code += `    Input Text    tag:input    ${step.text}\n`;
          }
          break;
        case 'scroll':
          if (step.direction === 'top') {
            code += `    Execute Javascript    window.scrollTo(0, 0)\n`;
          } else {
            code += `    Execute Javascript    window.scrollTo(0, document.body.scrollHeight)\n`;
          }
          break;
        case 'assert':
          if (step.selector) {
            code += `    Element Should Be Visible    ${step.selector}\n`;
          } else if (step.text) {
            code += `    Element Should Be Visible    xpath=//*[contains(text(), '${step.text}')]\n`;
          } else {
            code += `    Element Should Be Visible    tag:body\n`;
          }
          break;
      }
    });

    console.log('✅ SIDEPANEL ROBOT CODE GERADO:', code);
    return code;
  }

  generateSeleniumTest() {
    console.log('🌐 SIDEPANEL GERANDO SELENIUM TEST...');
    
    let code = `from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import unittest

class TesteAutomatizado(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Chrome()
        self.wait = WebDriverWait(self.driver, 10)
    
    def test_passos_gravados(self):
        """Executa passos gravados"""\n`;

    this.stepsManager.steps.forEach((step, index) => {
      console.log(`🔄 SIDEPANEL Processando step ${index + 1}:`, step);
      
      switch (step.type) {
        case 'navigate':
          code += `        self.driver.get('${step.url}')\n`;
          break;
        case 'click':
          if (step.selector) {
            code += `        element = self.wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, '${step.selector}')))\n        element.click()\n`;
          } else if (step.text) {
            code += `        element = self.wait.until(EC.element_to_be_clickable((By.XPATH, "//*[contains(text(), '${step.text}')]")))\n        element.click()\n`;
          } else if (step.element) {
            code += `        element = self.wait.until(EC.element_to_be_clickable((By.XPATH, "//*[contains(text(), '${step.element}')]")))\n        element.click()\n`;
          } else {
            code += `        element = self.wait.until(EC.element_to_be_clickable((By.TAG_NAME, 'button')))\n        element.click()\n`;
          }
          break;
        case 'type':
          if (step.selector && step.text) {
            code += `        element = self.wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, '${step.selector}')))\n        element.clear()\n        element.send_keys('${step.text}')\n`;
          } else if (step.text) {
            code += `        element = self.wait.until(EC.presence_of_element_located((By.TAG_NAME, 'input')))\n        element.send_keys('${step.text}')\n`;
          }
          break;
        case 'scroll':
          if (step.direction === 'top') {
            code += `        self.driver.execute_script("window.scrollTo(0, 0);")\n`;
          } else {
            code += `        self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")\n`;
          }
          break;
        case 'assert':
          if (step.selector) {
            code += `        element = self.wait.until(EC.visibility_of_element_located((By.CSS_SELECTOR, '${step.selector}')))\n        self.assertTrue(element.is_displayed())\n`;
          } else if (step.text) {
            code += `        element = self.wait.until(EC.visibility_of_element_located((By.XPATH, "//*[contains(text(), '${step.text}')]")))\n        self.assertTrue(element.is_displayed())\n`;
          } else {
            code += `        element = self.wait.until(EC.visibility_of_element_located((By.TAG_NAME, 'body')))\n        self.assertTrue(element.is_displayed())\n`;
          }
          break;
      }
    });

    code += `
    def tearDown(self):
        self.driver.quit()

if __name__ == '__main__':
    unittest.main()`;

    console.log('✅ SIDEPANEL SELENIUM CODE GERADO:', code);
    return code;
  }

  downloadFile(filename, content) {
    console.log('💾 SIDEPANEL FAZENDO DOWNLOAD:', filename);
    console.log('📄 SIDEPANEL CONTEÚDO DO ARQUIVO:', content);
    
    const blob = new Blob([content], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    URL.revokeObjectURL(url);
  }
}
