
// Extension UI Manager - VERSÃO REFATORADA CORRIGIDA
class ExtensionUI {
  constructor() {
    console.log('🎨 ExtensionUI: Construtor iniciado - VERSÃO REFATORADA CORRIGIDA');
    this.authManager = null;
    
    // Initialize managers - CORRIGIDO para usar as classes corretas
    this.uiManager = new UIManager();
    this.moduleLoader = new ModuleLoader();
    this.recorderManager = new RecorderManager(this.uiManager);
    this.formManager = null; // Will be initialized when authManager is set
  }

  setAuthManager(authManager) {
    console.log('🔗 ExtensionUI: AuthManager definido');
    this.authManager = authManager;
    this.formManager = new FormManager(authManager, this.uiManager);
  }

  setupLoginForm() {
    console.log('📝 ExtensionUI: Delegando configuração do formulário para FormManager...');
    if (this.formManager) {
      this.formManager.setupLoginForm();
    } else {
      console.error('❌ ExtensionUI: FormManager não inicializado. AuthManager deve ser definido primeiro.');
    }
  }

  showMessage(message, type) {
    this.uiManager.showMessage(message, type);
  }

  showLoginInterface() {
    this.uiManager.showLoginInterface();
  }

  async showRecorderInterface() {
    console.log('🎬 ExtensionUI: === PREPARANDO INTERFACE DE GRAVAÇÃO ===');
    
    // Primeiro mudar a UI usando o UIManager
    await this.uiManager.showRecorderInterface();
    
    // Carregar módulos apenas se não foram carregados ainda
    if (!this.moduleLoader.isLoaded()) {
      console.log('📦 ExtensionUI: Carregando módulos do gravador...');
      try {
        await this.moduleLoader.loadModulesAndInitialize();
        this.recorderManager.initializeRecorder();
      } catch (error) {
        console.error('💥 ExtensionUI: Erro ao carregar módulos:', error);
        this.showMessage('Erro ao carregar módulos. Recarregue a página.', 'error');
      }
    } else {
      console.log('✅ ExtensionUI: Módulos já carregados, pulando carregamento');
    }
    
    console.log('🎬 ExtensionUI: === INTERFACE DE GRAVAÇÃO CONFIGURADA ===');
  }
}
