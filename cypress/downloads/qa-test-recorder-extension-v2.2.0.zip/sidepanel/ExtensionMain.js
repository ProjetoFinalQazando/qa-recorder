
// Extension Main Coordinator - VERSÃO FINAL SIMPLIFICADA
class ExtensionMain {
  constructor() {
    console.log('🏗️ ExtensionMain: CONSTRUTOR iniciado - VERSÃO FINAL');
    
    this.uiManager = new ExtensionUI();
    this.authManager = new ExtensionAuth(this.uiManager);
    
    // Connect managers
    this.uiManager.setAuthManager(this.authManager);
    
    console.log('🔗 ExtensionMain: Managers conectados, iniciando...');
    this.initialize();
  }

  async initialize() {
    console.log('🎬 ExtensionMain: Iniciando extensão...');
    
    // Load auth modules first
    await this.loadAuthModules();
    
    // Setup event listeners e forms PRIMEIRO
    console.log('🎧 ExtensionMain: Configurando event listeners...');
    this.authManager.setupEventListeners();
    this.uiManager.setupLoginForm();
    
    // Aguardar UI estar pronta e então verificar autenticação com delay menor
    console.log('⏱️ ExtensionMain: Aguardando UI estar pronta...');
    setTimeout(async () => {
      console.log('🔍 ExtensionMain: Verificando autenticação...');
      await this.authManager.initializeAuth();
    }, 500);
  }

  async loadAuthModules() {
    try {
      console.log('📦 ExtensionMain: Carregando módulos de autenticação...');
      
      await this.loadScript('sidepanel/auth/AuthState.js');
      await this.loadScript('sidepanel/auth/AuthAPI.js');
      await this.loadScript('sidepanel/auth/AuthStorage.js');
      
      console.log('✅ ExtensionMain: Módulos de autenticação carregados');
    } catch (error) {
      console.error('💥 ExtensionMain: Erro ao carregar módulos de autenticação:', error);
    }
  }

  loadScript(src) {
    return new Promise((resolve, reject) => {
      if (document.querySelector(`script[src="${src}"]`)) {
        resolve();
        return;
      }
      
      const script = document.createElement('script');
      script.src = src;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });
  }
}
