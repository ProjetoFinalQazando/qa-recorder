
class SidepanelAuth {
  constructor(recorder) {
    this.recorder = recorder;
    this.userRole = 'free';
    this.canGenerate = true;
  }

  setupAuthListener() {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && (changes.supabaseSession || changes.isLoggedIn)) {
        console.log('Auth state changed, rechecking user access');
        this.checkUserAccess();
      }
    });
  }

  async checkUserAccess() {
    try {
      const result = await chrome.storage.local.get(['supabaseSession']);
      
      if (!result.supabaseSession?.access_token) {
        console.log('No authenticated user found');
        this.showAccessDenied();
        return;
      }

      const response = await fetch('https://wgkqubeyrynygzkvoezq.supabase.co/functions/v1/track-generation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${result.supabaseSession.access_token}`,
        },
        body: JSON.stringify({ action: 'check-limit' })
      });

      if (response.ok) {
        const data = await response.json();
        this.canGenerate = data.canGenerate;
        this.userRole = data.userRole;
        
        console.log('Access status:', {
          canGenerate: this.canGenerate,
          role: this.userRole,
          isExpired: data.isExpired,
          trialExpired: data.trialExpired
        });
        
        if (!this.canGenerate) {
          this.showAccessDenied();
        } else {
          this.hideAccessMessage();
        }
      } else {
        console.error('Failed to check user access');
        this.showAccessDenied();
      }
    } catch (error) {
      console.error('Error checking user access:', error);
      this.showAccessDenied();
    }
  }

  hideAccessMessage() {
    const existingMessage = document.getElementById('accessMessage');
    if (existingMessage) {
      existingMessage.remove();
    }
    
    if (this.canGenerate) {
      this.recorder.recordButton.disabled = false;
      this.recorder.recordButton.style.opacity = '1';
      this.recorder.recordButton.style.cursor = 'pointer';
      
      this.recorder.exportCypress.disabled = false;
      this.recorder.exportCypress.style.opacity = '1';
      this.recorder.exportCypress.style.cursor = 'pointer';
      
      this.recorder.exportPlaywright.disabled = false;
      this.recorder.exportPlaywright.style.opacity = '1';
      this.recorder.exportPlaywright.style.cursor = 'pointer';
    }
  }

  showAccessDenied() {
    this.recorder.recordButton.disabled = true;
    this.recorder.recordButton.style.opacity = '0.5';
    this.recorder.recordButton.style.cursor = 'not-allowed';
    
    this.recorder.exportCypress.disabled = true;
    this.recorder.exportCypress.style.opacity = '0.5';
    this.recorder.exportCypress.style.cursor = 'not-allowed';
    
    this.recorder.exportPlaywright.disabled = true;
    this.recorder.exportPlaywright.style.opacity = '0.5';
    this.recorder.exportPlaywright.style.cursor = 'not-allowed';

    const existingMessage = document.getElementById('accessMessage');
    if (existingMessage) return;

    const accessMessage = document.createElement('div');
    accessMessage.id = 'accessMessage';
    accessMessage.style.cssText = `
      background: #fee2e2;
      border: 1px solid #fecaca;
      color: #991b1b;
      padding: 12px;
      border-radius: 8px;
      margin: 10px 0;
      text-align: center;
      font-size: 14px;
    `;
    
    let message;
    if (this.userRole === 'free') {
      message = '<strong>⏰ Período de teste expirado!</strong><br>Faça upgrade para versão Premium para continuar usando';
    } else if (this.userRole === 'mensal') {
      message = '<strong>💳 Assinatura expirada!</strong><br>Entre na aplicação web para renovar sua assinatura';
    } else {
      message = '<strong>❌ Acesso negado!</strong><br>Verifique seu plano na aplicação web';
    }
    
    accessMessage.innerHTML = message;

    const container = document.querySelector('.container') || document.body;
    const recordButton = this.recorder.recordButton.parentElement || this.recorder.recordButton;
    container.insertBefore(accessMessage, recordButton);
  }

  showUpgradePrompt() {
    if (this.userRole === 'free') {
      alert('⏰ Período de teste expirado! Faça upgrade para a versão Premium para continuar usando a extensão.');
    } else if (this.userRole === 'mensal') {
      alert('💳 Sua assinatura expirou. Acesse a aplicação web para renovar.');
    } else {
      alert('❌ Acesso negado. Verifique seu plano na aplicação web.');
    }
  }

  async recordGeneration(testType, stepsCount) {
    try {
      const result = await chrome.storage.local.get(['supabaseSession']);
      
      if (!result.supabaseSession?.access_token) {
        console.log('No authenticated user for recording generation');
        return;
      }

      const response = await fetch('https://wgkqubeyrynygzkvoezq.supabase.co/functions/v1/track-generation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${result.supabaseSession.access_token}`,
        },
        body: JSON.stringify({
          action: 'record-generation',
          testType,
          stepsCount
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        if (response.status === 403) {
          this.canGenerate = false;
          this.showAccessDenied();
          alert('Acesso negado ou assinatura expirada!');
        }
      }
    } catch (error) {
      console.error('Error recording generation:', error);
    }
  }
}
