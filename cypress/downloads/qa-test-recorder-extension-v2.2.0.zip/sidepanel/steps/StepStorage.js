
class StepStorage {
  async saveSteps(steps) {
    try {
      await chrome.storage.local.set({
        steps: steps
      });
    } catch (error) {
      console.error('Error saving steps state:', error);
    }
  }

  async loadSteps() {
    try {
      const result = await chrome.storage.local.get(['steps']);
      return result.steps || [];
    } catch (error) {
      console.error('Error loading steps state:', error);
      return [];
    }
  }

  async clearSteps() {
    try {
      await chrome.storage.local.set({
        steps: []
      });
    } catch (error) {
      console.error('Error clearing steps state:', error);
    }
  }

  setupStorageListener(onStepsChanged) {
    chrome.storage.onChanged.addListener((changes, namespace) => {
      if (namespace === 'local' && changes.steps) {
        const newSteps = changes.steps.newValue || [];
        onStepsChanged(newSteps);
      }
    });
  }
}
