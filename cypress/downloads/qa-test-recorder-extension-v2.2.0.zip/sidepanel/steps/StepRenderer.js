
class StepRenderer {
  constructor(stepsList, stepsCount) {
    this.stepsList = stepsList;
    this.stepsCount = stepsCount;
  }

  renderSteps(steps, lastRenderedStepsCount) {
    if (!this.stepsList) return lastRenderedStepsCount;
    
    // Evitar re-renderização desnecessária
    if (lastRenderedStepsCount === steps.length) {
      return lastRenderedStepsCount;
    }
    
    this.stepsList.innerHTML = '';
    
    if (steps.length === 0) {
      this.stepsList.innerHTML = `
        <div style="padding: 20px; text-align: center; opacity: 0.7;">
          Nenhum passo gravado ainda
        </div>
      `;
      return steps.length;
    }
    
    // Remover duplicatas baseadas em tipo, seletor e timestamp próximo
    const uniqueSteps = steps.filter((step, index, array) => {
      return !array.slice(0, index).some(prevStep => 
        prevStep.type === step.type &&
        prevStep.selector === step.selector &&
        Math.abs(prevStep.timestamp - step.timestamp) < 1000
      );
    });
    
    uniqueSteps.slice(-20).forEach(step => {
      const stepElement = this.createStepElement(step);
      this.stepsList.appendChild(stepElement);
    });

    this.stepsList.scrollTop = this.stepsList.scrollHeight;
    return steps.length;
  }

  createStepElement(step) {
    const stepElement = document.createElement('div');
    stepElement.className = 'step-item';
    stepElement.style.cssText = `
      display: flex;
      align-items: center;
      padding: 8px;
      margin-bottom: 4px;
      background: white;
      border-radius: 4px;
      border-left: 3px solid #10b981;
    `;
    
    const icon = document.createElement('div');
    icon.className = 'step-icon';
    icon.style.cssText = `
      margin-right: 8px;
      font-size: 16px;
    `;
    icon.textContent = this.getStepIcon(step.type);
    
    const description = document.createElement('div');
    description.className = 'step-text';
    description.style.cssText = `
      flex: 1;
      font-size: 14px;
      color: #333;
    `;
    description.textContent = this.getStepDescription(step);
    
    stepElement.appendChild(icon);
    stepElement.appendChild(description);
    
    return stepElement;
  }

  getStepIcon(type) {
    const icons = {
      click: '👆',
      type: '⌨️',
      scroll: '🖱️',
      assert: '✅',
      navigate: '🔗',
      check: '☑️',
      select: '📋'
    };
    return icons[type] || '•';
  }

  getStepDescription(step) {
    switch (step.type) {
      case 'click':
        return `Click em ${step.element || 'elemento'}`;
      case 'type':
        return `Digitou: "${step.text || step.value || ''}"`;
      case 'scroll':
        return `Scroll para ${step.direction || 'baixo'}`;
      case 'assert':
        return `Assert: ${step.assertion || 'elemento existe'}`;
      case 'navigate':
        return `Navegou para: ${step.url || ''}`;
      case 'check':
        return `${step.checked ? 'Marcou' : 'Desmarcou'} checkbox`;
      case 'select':
        return `Selecionou: "${step.text || step.value}"`;
      default:
        return `Ação: ${step.type}`;
    }
  }

  updateStepsCounter(stepsCount) {
    if (!this.stepsCount) return;
    
    const count = stepsCount;
    this.stepsCount.textContent = `${count} passo${count !== 1 ? 's' : ''} gravado${count !== 1 ? 's' : ''}`;
  }

  clearDisplay() {
    if (!this.stepsList) return;
    
    this.stepsList.innerHTML = `
      <div style="padding: 20px; text-align: center; opacity: 0.7;">
        Nenhum passo gravado ainda
      </div>
    `;
  }
}
