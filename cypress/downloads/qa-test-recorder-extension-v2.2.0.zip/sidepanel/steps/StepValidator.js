
class StepValidator {
  isDuplicateStep(steps, newStep) {
    return steps.some(existingStep => 
      existingStep.id === newStep.id || 
      (existingStep.type === newStep.type && 
       existingStep.selector === newStep.selector && 
       Math.abs(existingStep.timestamp - newStep.timestamp) < 1000)
    );
  }

  findExistingStep(steps, step) {
    return steps.find(existingStep => 
      existingStep.id === step.id || 
      (existingStep.type === step.type && 
       existingStep.selector === step.selector && 
       Math.abs(existingStep.timestamp - step.timestamp) < 1000)
    );
  }

  generateId() {
    return Math.random().toString(36).substr(2, 9);
  }

  validateStep(step) {
    return {
      ...step,
      timestamp: step.timestamp || Date.now(),
      id: step.id || this.generateId()
    };
  }
}
