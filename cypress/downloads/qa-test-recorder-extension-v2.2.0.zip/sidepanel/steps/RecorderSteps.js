
class RecorderSteps {
  constructor() {
    this.steps = [];
    this.stepsList = document.getElementById('stepsList');
    this.stepsCount = document.getElementById('stepsCount');
    this.lastRenderedStepsCount = 0;
    
    // Initialize modules
    this.renderer = new StepRenderer(this.stepsList, this.stepsCount);
    this.storage = new StepStorage();
    this.validator = new StepValidator();
    
    this.setupEventListeners();
    this.setupStorageListener();
  }

  setupEventListeners() {
    // Escutar mensagens do content script
    chrome.runtime.onMessage.addListener((message) => {
      if (message.type === 'stepRecorded') {
        // Verificar se o step já existe para evitar duplicação
        const existingStep = this.validator.findExistingStep(this.steps, message.step);
        
        if (!existingStep) {
          this.addStep(message.step);
        } else {
          console.log('Step duplicado ignorado:', message.step);
        }
      }
    });
  }

  setupStorageListener() {
    this.storage.setupStorageListener((newSteps) => {
      // Só atualizar se realmente houve mudança no número de steps
      if (newSteps.length !== this.steps.length) {
        this.steps = newSteps;
        this.renderSteps();
        this.updateStepsCounter();
      }
    });
  }

  addStep(step) {
    // Verificar duplicação antes de adicionar
    if (!this.validator.isDuplicateStep(this.steps, step)) {
      const validatedStep = this.validator.validateStep(step);
      this.steps.push(validatedStep);
      
      this.renderSteps();
      this.updateStepsCounter();
      this.saveState();
    }
  }

  renderSteps() {
    this.lastRenderedStepsCount = this.renderer.renderSteps(this.steps, this.lastRenderedStepsCount);
  }

  updateStepsCounter() {
    this.renderer.updateStepsCounter(this.steps.length);
  }

  async clearSteps() {
    if (confirm('Tem certeza que deseja limpar todos os passos gravados?')) {
      console.log('🗑️ Limpando steps...');
      
      // Limpar array local
      this.steps = [];
      this.lastRenderedStepsCount = 0;
      
      // Forçar re-renderização
      this.renderer.clearDisplay();
      
      // Atualizar contador
      this.updateStepsCounter();
      
      // Salvar no storage
      await this.saveState();
      
      console.log('✅ Steps limpos com sucesso');
    }
  }

  async saveState() {
    await this.storage.saveSteps(this.steps);
  }

  async loadState() {
    try {
      this.steps = await this.storage.loadSteps();
      this.renderSteps();
      this.updateStepsCounter();
    } catch (error) {
      console.error('Error loading steps state:', error);
    }
  }

  generateId() {
    return this.validator.generateId();
  }
}
