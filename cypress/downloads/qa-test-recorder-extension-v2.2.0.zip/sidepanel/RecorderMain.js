class RecorderMain {
  constructor() {
    this.isRecording = false;
    this.assertMode = false;
    this.stepsManager = new RecorderSteps();
    this.tabId = null;
    this.setupElements();
    this.setupEventListeners();
    this.loadState();
    this.initializeTabTracking();
  }

  setupElements() {
    this.recordButton = document.getElementById('recordButton');
    this.status = document.getElementById('status');
    this.clearButton = document.getElementById('clearButton');
    this.exportButtons = {
      cypress: document.getElementById('exportCypress'),
      playwright: document.getElementById('exportPlaywright'),
      robot: document.getElementById('exportRobot'),
      selenium: document.getElementById('exportSelenium')
    };
  }

  async initializeTabTracking() {
    try {
      // Obter aba ativa atual
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      this.tabId = tab.id;

      // Registrar esta aba como a aba ativa do sidepanel
      await chrome.storage.local.set({
        activeSidepanelTab: tab.id,
        sidepanelWindowId: tab.windowId
      });

      // Informar background script
      chrome.runtime.sendMessage({
        type: 'setSidepanelTab',
        tabId: tab.id
      }).catch(() => {
        console.log('Background script não disponível');
      });

      console.log(`📱 Sidepanel vinculado à aba ${tab.id}`);
    } catch (error) {
      console.error('Erro ao inicializar tracking de aba:', error);
    }
  }

  setupEventListeners() {
    if (this.recordButton) {
      this.recordButton.addEventListener('click', () => {
        this.toggleRecording();
      });
    }

    if (this.clearButton) {
      this.clearButton.addEventListener('click', () => {
        this.stepsManager.clearSteps();
      });
    }

    // Export buttons
    Object.keys(this.exportButtons).forEach(framework => {
      const button = this.exportButtons[framework];
      if (button) {
        button.addEventListener('click', () => {
          this.exportTest(framework);
        });
      }
    });

    // Listen apenas para mudanças de storage relevantes
    chrome.storage.onChanged.addListener((changes, namespace) => {
      if (namespace === 'local') {
        if (changes.isRecording) {
          this.isRecording = changes.isRecording.newValue;
          this.updateUI();
        }
        if (changes.steps) {
          this.stepsManager.steps = changes.steps.newValue || [];
          this.stepsManager.renderSteps();
          this.stepsManager.updateStepsCounter();
        }
      }
    });

    // Listen for messages - apenas para steps
    chrome.runtime.onMessage.addListener((message) => {
      if (message.type === 'stepRecorded') {
        // Verificar se é da nossa aba
        if (message.step.tabId === this.tabId) {
          this.stepsManager.addStep(message.step);
        }
      }
    });

    // Monitor mudanças de foco do documento
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden) {
        this.refreshState();
      }
    });

    window.addEventListener('focus', () => {
      this.refreshState();
    });
  }

  async refreshState() {
    try {
      await this.loadState();
      await this.stepsManager.loadState();
      console.log('🔄 Estado atualizado');
    } catch (error) {
      console.error('Erro ao atualizar estado:', error);
    }
  }

  async toggleRecording() {
    try {
      // Verificar se estamos na aba correta
      const result = await chrome.storage.local.get(['activeSidepanelTab']);
      if (result.activeSidepanelTab !== this.tabId) {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        this.tabId = tab.id;
        await chrome.storage.local.set({ activeSidepanelTab: tab.id });
      }

      if (this.isRecording) {
        await chrome.tabs.sendMessage(this.tabId, { 
          type: 'stopRecording' 
        });
        this.isRecording = false;
        console.log('🛑 Gravação parada');
      } else {
        await chrome.tabs.sendMessage(this.tabId, { 
          type: 'startRecording',
          assertMode: this.assertMode
        });
        this.isRecording = true;
        console.log('🚀 Gravação iniciada');
      }
      
      this.updateUI();
      await this.saveState();
    } catch (error) {
      console.error('Error toggling recording:', error);
      this.showError('Erro ao alterar gravação. Recarregue a página e tente novamente.');
    }
  }

  updateUI() {
    if (!this.recordButton || !this.status) return;

    if (this.isRecording) {
      this.recordButton.textContent = '⏹️ Parar Gravação';
      this.recordButton.style.background = '#ef4444';
      this.status.textContent = 'Status: Gravando...';
      this.status.style.background = '#dcfce7';
      this.status.style.color = '#166534';
    } else {
      this.recordButton.textContent = '⏺️ Iniciar Gravação';
      this.recordButton.style.background = '#10b981';
      this.status.textContent = 'Status: Parado';
      this.status.style.background = '#fee2e2';
      this.status.style.color = '#991b1b';
    }
  }

  async exportTest(framework) {
    if (this.stepsManager.steps.length === 0) {
      alert('Nenhum passo gravado para exportar!');
      return;
    }

    try {
      const code = this.generateTestCode(framework, this.stepsManager.steps);
      this.downloadFile(`test.${this.getFileExtension(framework)}`, code);
    } catch (error) {
      console.error('Error exporting test:', error);
      this.showError('Erro ao exportar teste.');
    }
  }

  generateTestCode(framework, steps) {
    switch (framework) {
      case 'cypress':
        return this.generateCypressCode(steps);
      case 'playwright':
        return this.generatePlaywrightCode(steps);
      case 'robot':
        return this.generateRobotCode(steps);
      case 'selenium':
        return this.generateSeleniumCode(steps);
      default:
        throw new Error('Framework não suportado');
    }
  }

  generateCypressCode(steps) {
    let code = `describe('Teste Automatizado', () => {\n`;
    code += `  it('Deve executar as ações gravadas', () => {\n`;
    
    steps.forEach(step => {
      switch (step.type) {
        case 'click':
          code += `    cy.get('${step.selector}').click();\n`;
          break;
        case 'type':
          code += `    cy.get('${step.selector}').type('${step.text || step.value}');\n`;
          break;
        case 'assert':
          code += `    cy.get('${step.selector}').should('${step.assertion}');\n`;
          break;
        case 'navigate':
          code += `    cy.visit('${step.url}');\n`;
          break;
      }
    });
    
    code += `  });\n});`;
    return code;
  }

  generatePlaywrightCode(steps) {
    let code = `import { test, expect } from '@playwright/test';\n\n`;
    code += `test('Teste Automatizado', async ({ page }) => {\n`;
    
    steps.forEach(step => {
      switch (step.type) {
        case 'click':
          code += `  await page.click('${step.selector}');\n`;
          break;
        case 'type':
          code += `  await page.fill('${step.selector}', '${step.text || step.value}');\n`;
          break;
        case 'assert':
          code += `  await expect(page.locator('${step.selector}')).toBeVisible();\n`;
          break;
        case 'navigate':
          code += `  await page.goto('${step.url}');\n`;
          break;
      }
    });
    
    code += `});`;
    return code;
  }

  generateRobotCode(steps) {
    let code = `*** Settings ***\nLibrary    SeleniumLibrary\n\n`;
    code += `*** Test Cases ***\nTeste Automatizado\n`;
    
    steps.forEach(step => {
      switch (step.type) {
        case 'click':
          code += `    Click Element    ${step.selector}\n`;
          break;
        case 'type':
          code += `    Input Text    ${step.selector}    ${step.text || step.value}\n`;
          break;
        case 'assert':
          code += `    Element Should Be Visible    ${step.selector}\n`;
          break;
        case 'navigate':
          code += `    Go To    ${step.url}\n`;
          break;
      }
    });
    
    return code;
  }

  generateSeleniumCode(steps) {
    let code = `from selenium import webdriver\nfrom selenium.webdriver.common.by import By\n\n`;
    code += `def test_automatizado():\n`;
    code += `    driver = webdriver.Chrome()\n`;
    
    steps.forEach(step => {
      switch (step.type) {
        case 'click':
          code += `    driver.find_element(By.CSS_SELECTOR, "${step.selector}").click()\n`;
          break;
        case 'type':
          code += `    driver.find_element(By.CSS_SELECTOR, "${step.selector}").send_keys("${step.text || step.value}")\n`;
          break;
        case 'navigate':
          code += `    driver.get("${step.url}")\n`;
          break;
      }
    });
    
    code += `    driver.quit()\n`;
    return code;
  }

  getFileExtension(framework) {
    const extensions = {
      cypress: 'cy.js',
      playwright: 'spec.js',
      robot: 'robot',
      selenium: 'py'
    };
    return extensions[framework] || 'txt';
  }

  downloadFile(filename, content) {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  async saveState() {
    try {
      await chrome.storage.local.set({
        isRecording: this.isRecording,
        assertMode: this.assertMode,
        currentTabId: this.tabId
      });
    } catch (error) {
      console.error('Error saving state:', error);
    }
  }

  async loadState() {
    try {
      const result = await chrome.storage.local.get([
        'isRecording', 
        'assertMode', 
        'currentTabId',
        'activeSidepanelTab'
      ]);
      
      this.isRecording = result.isRecording || false;
      this.assertMode = result.assertMode || false;
      this.tabId = result.activeSidepanelTab || this.tabId;
      
      this.updateUI();
      await this.stepsManager.loadState();
    } catch (error) {
      console.error('Error loading state:', error);
    }
  }

  showError(message) {
    alert(message);
  }
}
