
// Extension Authentication Manager - VERSÃO REFATORADA
class ExtensionAuth {
  constructor(uiManager) {
    console.log('🔐 ExtensionAuth: Construtor iniciado - VERSÃO REFATORADA');
    this.uiManager = uiManager;
    
    // Initialize modules
    this.authState = new AuthState();
    this.authAPI = new AuthAPI();
    this.authStorage = new AuthStorage();
  }

  async initializeAuth() {
    try {
      console.log('🔍 ExtensionAuth: === INICIANDO VERIFICAÇÃO DE AUTENTICAÇÃO ===');
      
      // CRÍTICO: Se estamos no processo de autenticação ou login foi completado, não verificar
      if (this.authState.shouldSkipCheck()) {
        console.log('🔒 ExtensionAuth: PULANDO verificação - processo em andamento ou concluído');
        console.log('🔒 ExtensionAuth: Mantendo interface atual...');
        return;
      }
      
      const sessionData = await this.authStorage.getStoredSession();
      
      console.log('📊 ExtensionAuth: Status de autenticação encontrado');
      this.authState.logCurrentState();
      
      // SEMPRE na primeira verificação, manter login visível INDEPENDENTE do status
      if (this.authState.isFirstCheck()) {
        console.log('🔒 ExtensionAuth: === PRIMEIRA VERIFICAÇÃO - SEMPRE MANTENDO LOGIN VISÍVEL ===');
        this.uiManager.showLoginInterface();
        this.authState.setInitialCheck(false);
        return;
      }
      
      // Verificar se o usuário tem sessão válida
      if (this.authStorage.hasValidSession(sessionData) && this.authState.canProceedWithAuth()) {
        console.log('✅ ExtensionAuth: Usuário autenticado encontrado, MUDANDO para interface de gravação...');
        await this.uiManager.showRecorderInterface();
      } else {
        console.log('❌ ExtensionAuth: Usuário não autenticado, MANTENDO tela de login');
        this.uiManager.showLoginInterface();
      }
    } catch (error) {
      console.error('💥 ExtensionAuth: Erro ao verificar status de autenticação:', error);
      console.log('🔒 ExtensionAuth: FORÇANDO tela de login devido ao erro');
      this.uiManager.showLoginInterface();
    }
  }

  setupEventListeners() {
    console.log('🎧 ExtensionAuth: Configurando event listeners...');
    
    // Setup storage listener with callback - MAS só se não estamos autenticando
    this.authStorage.setupStorageListener(() => {
      if (!this.authState.shouldSkipCheck()) {
        console.log('🔄 ExtensionAuth: Storage mudou, verificando autenticação...');
        this.initializeAuth();
      } else {
        console.log('🚫 ExtensionAuth: Storage mudou mas pulando verificação - processo em andamento');
      }
    }, this.authState);
  }

  async handleLogin() {
    console.log('🔑 ExtensionAuth: === INICIANDO PROCESSO DE LOGIN ===');
    
    // Marcar que estamos autenticando
    this.authState.setAuthenticating(true);
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const loginButton = document.getElementById('loginButton');

    if (!email || !password) {
      console.log('⚠️ ExtensionAuth: Email ou senha não preenchidos');
      this.uiManager.showMessage('Por favor, preencha email e senha.', 'error');
      this.authState.setAuthenticating(false);
      return;
    }

    loginButton.disabled = true;
    loginButton.textContent = 'Entrando...';

    try {
      // Fazer login
      const loginData = await this.authAPI.login(email, password);

      if (loginData.access_token) {
        // Verificar role e permissões do usuário
        const roleData = await this.authAPI.checkUserRole(loginData.access_token);
        
        // Validar acesso
        this.authAPI.validateUserAccess(roleData);

        // Salvar dados da sessão
        await this.authStorage.saveSession(loginData, roleData.userRole);

        console.log('🎉 ExtensionAuth: === LOGIN CONCLUÍDO COM SUCESSO ===');
        this.uiManager.showMessage('Login realizado com sucesso!', 'success');
        
        // MARCAR LOGIN COMO CONCLUÍDO ANTES DE REDIRECIONAR
        this.authState.setLoginCompleted(true);
        this.authState.setAuthenticating(false);
        
        console.log('🔄 ExtensionAuth: EXECUTANDO MUDANÇA IMEDIATA para interface de gravação...');
        
        // FORÇAR mudança imediata usando método direto - SEM AGUARDAR
        console.log('🎬 ExtensionAuth: === MUDANDO PARA INTERFACE DE GRAVAÇÃO AGORA ===');
        await this.uiManager.showRecorderInterface();
        
        console.log('✅ ExtensionAuth: === PROCESSO DE LOGIN E REDIRECIONAMENTO FINALIZADO ===');

      } else {
        console.error('❌ ExtensionAuth: Resposta de login inválida - sem access_token');
        throw new Error('Resposta de login inválida.');
      }
    } catch (error) {
      console.error('💥 ExtensionAuth: Erro no login:', error);
      this.uiManager.showMessage(error.message || 'Erro no login. Verifique suas credenciais e tente novamente.', 'error');
      this.authState.setAuthenticating(false);
      this.authState.setLoginCompleted(false);
    } finally {
      loginButton.disabled = false;
      loginButton.textContent = 'Entrar na Extensão';
    }
  }

  async handleLogout() {
    try {
      console.log('🚪 ExtensionAuth: === INICIANDO LOGOUT ===');
      
      // Limpar todos os dados armazenados
      await this.authStorage.clearAllData();
      
      // Resetar todas as flags
      this.authState.resetState();
      
      // Mostrar interface de login
      this.uiManager.showLoginInterface();
      
      this.uiManager.showMessage('Logout realizado com sucesso!', 'success');
      console.log('✅ ExtensionAuth: === LOGOUT CONCLUÍDO ===');
    } catch (error) {
      console.error('💥 ExtensionAuth: Erro no logout:', error);
      this.authState.setAuthenticating(false);
      this.authState.setLoginCompleted(false);
    }
  }
}
