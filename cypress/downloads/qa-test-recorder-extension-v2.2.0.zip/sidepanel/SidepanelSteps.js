
class SidepanelSteps {
  constructor() {
    this.steps = [];
    this.stepsList = document.getElementById('stepsList');
    this.stepsCount = document.getElementById('stepsCount');
    this.clearButton = document.getElementById('clearButton');
  }

  addStep(step) {
    this.steps.push({
      ...step,
      timestamp: Date.now(),
      id: this.generateId()
    });
    
    this.renderSteps();
    this.updateStepsCounter();
    this.saveState();
  }

  renderSteps() {
    this.stepsList.innerHTML = '';
    
    this.steps.slice(-20).forEach(step => {
      const stepElement = document.createElement('div');
      stepElement.className = 'step-item';
      
      const icon = document.createElement('div');
      icon.className = `step-icon ${step.type}`;
      icon.textContent = this.getStepIcon(step.type);
      
      const description = document.createElement('div');
      description.className = 'step-text';
      description.textContent = this.getStepDescription(step);
      
      stepElement.appendChild(icon);
      stepElement.appendChild(description);
      this.stepsList.appendChild(stepElement);
    });

    this.stepsList.scrollTop = this.stepsList.scrollHeight;
  }

  getStepIcon(type) {
    const icons = {
      click: '👆',
      type: '⌨️',
      scroll: '🖱️',
      assert: '✅',
      navigate: '🔗'
    };
    return icons[type] || '•';
  }

  getStepDescription(step) {
    switch (step.type) {
      case 'click':
        return `Click em ${step.element || 'elemento'}`;
      case 'type':
        return `Digitou: "${step.text || ''}"`;
      case 'scroll':
        return `Scroll para ${step.direction || 'baixo'}`;
      case 'assert':
        return `Assert: ${step.assertion || 'elemento existe'}`;
      case 'navigate':
        return `Navegou para: ${step.url || ''}`;
      default:
        return `Ação: ${step.type}`;
    }
  }

  updateStepsCounter() {
    const count = this.steps.length;
    this.stepsCount.textContent = `${count} passo${count !== 1 ? 's' : ''} gravado${count !== 1 ? 's' : ''}`;
  }

  async clearSteps() {
    if (confirm('Tem certeza que deseja limpar todos os passos gravados?')) {
      this.steps = [];
      this.renderSteps();
      this.updateStepsCounter();
      await this.saveState();
    }
  }

  async saveState() {
    try {
      await chrome.storage.local.set({
        steps: this.steps
      });
    } catch (error) {
      console.error('Error saving steps state:', error);
    }
  }

  generateId() {
    return Math.random().toString(36).substr(2, 9);
  }
}
