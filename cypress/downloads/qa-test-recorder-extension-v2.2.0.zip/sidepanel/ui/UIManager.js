
// UI Manager - Handles UI state transitions and element management
class UIManager {
  constructor() {
    console.log('🎨 UIManager: Construtor iniciado');
  }

  showMessage(message, type) {
    console.log(`💬 UIManager: Mostrando mensagem (${type}):`, message);
    
    const messageContainer = document.getElementById('messageContainer');
    if (!messageContainer) {
      console.error('❌ UIManager: Container de mensagem não encontrado');
      return;
    }

    messageContainer.innerHTML = '';
    
    const messageDiv = document.createElement('div');
    messageDiv.className = type === 'success' ? 'success-message' : 'error-message';
    messageDiv.textContent = message;
    
    messageContainer.appendChild(messageDiv);
    
    // Limpar mensagem após 3 segundos
    setTimeout(() => {
      messageContainer.innerHTML = '';
    }, 3000);
  }

  showLoginInterface() {
    console.log('🔒 UIManager: === FORÇANDO INTERFACE DE LOGIN ===');
    
    const loginInterface = document.getElementById('loginInterface');
    const recorderInterface = document.getElementById('recorderInterface');
    
    if (!loginInterface || !recorderInterface) {
      console.error('❌ UIManager: Elementos de interface não encontrados!');
      return;
    }
    
    // FORÇAR visibilidade da interface de login
    loginInterface.style.display = 'flex';
    loginInterface.style.visibility = 'visible';
    loginInterface.style.opacity = '1';
    loginInterface.classList.add('active');
    console.log('✅ UIManager: Interface de login FORÇADA A APARECER');
    
    // FORÇAR ocultação da interface de gravação
    recorderInterface.style.display = 'none';
    recorderInterface.style.visibility = 'hidden';
    recorderInterface.style.opacity = '0';
    recorderInterface.classList.remove('active');
    console.log('✅ UIManager: Interface de gravação FORÇADA A FICAR OCULTA');
    
    this.clearLoginForm();
  }

  async showRecorderInterface() {
    console.log('🎬 UIManager: === FORÇANDO INTERFACE DE GRAVAÇÃO ===');
    
    const loginInterface = document.getElementById('loginInterface');
    const recorderInterface = document.getElementById('recorderInterface');
    
    if (!loginInterface || !recorderInterface) {
      console.error('❌ UIManager: Elementos de interface não encontrados!');
      return;
    }
    
    console.log('🔄 UIManager: Estado atual das interfaces ANTES da mudança:');
    console.log('- Login display:', loginInterface.style.display);
    console.log('- Recorder display:', recorderInterface.style.display);
    
    // PRIMEIRA FASE: FORÇAR ocultação da interface de login
    loginInterface.style.display = 'none !important';
    loginInterface.style.visibility = 'hidden !important';
    loginInterface.style.opacity = '0 !important';
    loginInterface.classList.remove('active');
    console.log('✅ UIManager: Interface de login BRUTALMENTE OCULTA');
    
    // SEGUNDA FASE: FORÇAR exibição da interface de gravação
    recorderInterface.style.display = 'flex !important';
    recorderInterface.style.visibility = 'visible !important';  
    recorderInterface.style.opacity = '1 !important';
    recorderInterface.classList.add('active');
    console.log('✅ UIManager: Interface de gravação BRUTALMENTE MOSTRADA');
    
    // TERCEIRA FASE: Aguardar e verificar se a mudança funcionou
    setTimeout(() => {
      console.log('🔍 UIManager: Verificando estado APÓS mudança:');
      console.log('- Login display:', loginInterface.style.display);
      console.log('- Recorder display:', recorderInterface.style.display);
      console.log('- Login visibility:', loginInterface.style.visibility);
      console.log('- Recorder visibility:', recorderInterface.style.visibility);
      
      if (recorderInterface.style.display === 'flex' || recorderInterface.style.display === 'flex !important') {
        console.log('🎉 UIManager: SUCESSO! Interface de gravação está visível');
      } else {
        console.error('💥 UIManager: FALHA! Interface de gravação ainda não está visível');
        // Tentar novamente com força bruta
        recorderInterface.setAttribute('style', 'display: flex !important; visibility: visible !important; opacity: 1 !important;');
        loginInterface.setAttribute('style', 'display: none !important; visibility: hidden !important; opacity: 0 !important;');
        console.log('🔧 UIManager: Aplicado força bruta com setAttribute');
      }
    }, 100);
    
    console.log('🎬 UIManager: === TRANSIÇÃO DE INTERFACE CONCLUÍDA ===');
  }

  clearLoginForm() {
    const emailInput = document.getElementById('email');
    const passwordInput = document.getElementById('password');
    if (emailInput) emailInput.value = '';
    if (passwordInput) passwordInput.value = '';
  }
}
