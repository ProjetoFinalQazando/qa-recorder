
// Recorder Manager - Handles recorder initialization and event attachment
class RecorderManager {
  constructor(uiManager) {
    console.log('🎬 RecorderManager: Construtor iniciado');
    this.uiManager = uiManager;
    this.recorder = null;
    this.stepsManager = null;
    this.auth = null;
    this.exporter = null;
  }

  initializeRecorder() {
    try {
      console.log('🎬 RecorderManager: Inicializando módulos do gravador...');
      
      // Inicializar os módulos do gravador
      this.stepsManager = new SidepanelSteps();
      this.recorder = new SidepanelRecorder(this.stepsManager);
      this.auth = new SidepanelAuth(this.recorder);
      this.exporter = new SidepanelExport(this.stepsManager, this.auth);
      
      // Conectar elementos
      this.recorder.recordButton = document.getElementById('recordButton');
      this.recorder.recordIcon = document.getElementById('recordIcon');
      this.recorder.recordText = document.getElementById('recordText');
      this.recorder.status = document.getElementById('status');
      this.recorder.assertToggle = document.getElementById('assertToggle');
      this.recorder.exportCypress = document.getElementById('exportCypress');
      this.recorder.exportPlaywright = document.getElementById('exportPlaywright');
      
      this.attachRecorderEvents();
      this.recorder.loadState();
      this.auth.checkUserAccess();
      
      console.log('✅ RecorderManager: Gravador inicializado com sucesso');
    } catch (error) {
      console.error('💥 RecorderManager: Erro ao inicializar gravador:', error);
      this.uiManager.showMessage('Erro ao inicializar gravador. Recarregue a página.', 'error');
    }
  }

  attachRecorderEvents() {
    const recordButton = document.getElementById('recordButton');
    const assertToggle = document.getElementById('assertToggle');
    const clearButton = document.getElementById('clearButton');
    const exportCypress = document.getElementById('exportCypress');
    const exportPlaywright = document.getElementById('exportPlaywright');
    const exportRobot = document.getElementById('exportRobot');
    const exportSelenium = document.getElementById('exportSelenium');

    if (recordButton) {
      recordButton.addEventListener('click', () => {
        if (recordButton.disabled) {
          this.auth.showUpgradePrompt();
          return;
        }
        this.recorder.toggleRecording();
      });
    }

    if (assertToggle) {
      assertToggle.addEventListener('click', () => this.recorder.toggleAssertMode());
    }

    if (clearButton) {
      clearButton.addEventListener('click', () => this.stepsManager.clearSteps());
    }

    if (exportCypress) {
      exportCypress.addEventListener('click', () => {
        if (exportCypress.disabled) {
          this.auth.showUpgradePrompt();
          return;
        }
        this.exporter.exportTest('cypress');
      });
    }

    if (exportPlaywright) {
      exportPlaywright.addEventListener('click', () => {
        if (exportPlaywright.disabled) {
          this.auth.showUpgradePrompt();
          return;
        }
        this.exporter.exportTest('playwright');
      });
    }

    if (exportRobot) {
      exportRobot.addEventListener('click', () => {
        if (exportRobot.disabled) {
          this.auth.showUpgradePrompt();
          return;
        }
        this.exporter.exportTest('robot');
      });
    }

    if (exportSelenium) {
      exportSelenium.addEventListener('click', () => {
        if (exportSelenium.disabled) {
          this.auth.showUpgradePrompt();
          return;
        }
        this.exporter.exportTest('selenium');
      });
    }

    // Escutar mensagens do content script
    chrome.runtime.onMessage.addListener((message) => {
      if (message.type === 'stepRecorded') {
        this.stepsManager.addStep(message.step);
      } else if (message.type === 'accessUpdated') {
        this.auth.checkUserAccess();
      }
    });
  }
}
