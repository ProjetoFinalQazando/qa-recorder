
// Module Loader - Handles dynamic loading of recorder modules
class ModuleLoader {
  constructor() {
    console.log('📦 ModuleLoader: Construtor iniciado');
    this.modulesLoaded = false;
  }

  async loadModulesAndInitialize() {
    try {
      console.log('📦 ModuleLoader: Carregando módulos do gravador...');
      
      // Carregar todos os scripts necessários dinamicamente
      await this.loadScript('sidepanel/SidepanelSteps.js');
      await this.loadScript('sidepanel/SidepanelRecorder.js');
      await this.loadScript('sidepanel/SidepanelAuth.js');
      await this.loadScript('sidepanel/SidepanelExport.js');
      
      console.log('✅ ModuleLoader: Todos os módulos carregados com sucesso');
      this.modulesLoaded = true;
      return true;
    } catch (error) {
      console.error('💥 ModuleLoader: Erro ao carregar módulos:', error);
      throw error;
    }
  }

  loadScript(src) {
    return new Promise((resolve, reject) => {
      // Verificar se o script já foi carregado
      if (document.querySelector(`script[src="${src}"]`)) {
        console.log(`⚠️ ModuleLoader: Script já carregado: ${src}`);
        resolve();
        return;
      }
      
      const script = document.createElement('script');
      script.src = src;
      script.onload = () => {
        console.log(`📁 ModuleLoader: Script carregado: ${src}`);
        resolve();
      };
      script.onerror = (error) => {
        console.error(`❌ ModuleLoader: Erro ao carregar script: ${src}`, error);
        reject(error);
      };
      document.head.appendChild(script);
    });
  }

  isLoaded() {
    return this.modulesLoaded;
  }
}
