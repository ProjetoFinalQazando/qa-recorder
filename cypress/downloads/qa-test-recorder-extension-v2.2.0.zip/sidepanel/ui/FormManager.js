
// Form Manager - Handles form setup and event listeners
class FormManager {
  constructor(authManager, uiManager) {
    console.log('📝 FormManager: Construtor iniciado');
    this.authManager = authManager;
    this.uiManager = uiManager;
  }

  setupLoginForm() {
    console.log('📝 FormManager: Configurando formulário de login...');
    
    const loginForm = document.getElementById('loginForm');
    const passwordToggle = document.getElementById('passwordToggle');
    const passwordInput = document.getElementById('password');
    const logoutButton = document.getElementById('logoutButton');

    // Funcionalidade de toggle da senha
    if (passwordToggle && passwordInput) {
      passwordToggle.addEventListener('click', () => {
        const type = passwordInput.type === 'password' ? 'text' : 'password';
        passwordInput.type = type;
        passwordToggle.textContent = type === 'password' ? '👁️' : '🙈';
      });
      console.log('👁️ FormManager: Toggle de senha configurado');
    }

    // Submissão do formulário de login
    if (loginForm) {
      loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        console.log('📤 FormManager: Formulário de login submetido');
        if (this.authManager) {
          await this.authManager.handleLogin();
        }
      });
      console.log('📋 FormManager: Event listener do formulário configurado');
    }

    // Funcionalidade de logout
    if (logoutButton) {
      logoutButton.addEventListener('click', async () => {
        console.log('🚪 FormManager: Botão de logout clicado');
        if (this.authManager) {
          await this.authManager.handleLogout();
        }
      });
      console.log('🚪 FormManager: Event listener do logout configurado');
    }
  }
}
