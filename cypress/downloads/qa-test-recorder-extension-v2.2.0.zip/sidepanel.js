
// Extension Sidepanel - Redirecionamento para nova estrutura
console.log('🔄 sidepanel.js: Redirecionando para nova estrutura de autenticação...');

// Este arquivo agora apenas garante que a nova estrutura seja carregada
// A lógica principal foi movida para extension-sidepanel.js

// Verificar se já temos a nova estrutura carregada
if (typeof ExtensionMain === 'undefined') {
  console.log('📦 sidepanel.js: Nova estrutura não carregada, forçando carregamento...');
  
  // Forçar a tela de login primeiro
  document.addEventListener('DOMContentLoaded', () => {
    console.log('📄 sidepanel.js: DOM carregado, forçando tela de login...');
    
    const loginInterface = document.getElementById('loginInterface');
    const recorderInterface = document.getElementById('recorderInterface');
    
    if (loginInterface) {
      loginInterface.style.display = 'flex';
      console.log('✅ sidepanel.js: Interface de login forçada');
    }
    
    if (recorderInterface) {
      recorderInterface.style.display = 'none';
      console.log('✅ sidepanel.js: Interface de gravação oculta');
    }
    
    // Carregar o novo sistema se não estiver carregado
    if (!document.querySelector('script[src="extension-sidepanel.js"]')) {
      console.log('🔄 sidepanel.js: Carregando extension-sidepanel.js...');
      const script = document.createElement('script');
      script.src = 'extension-sidepanel.js';
      document.head.appendChild(script);
    }
  });
} else {
  console.log('✅ sidepanel.js: Nova estrutura já carregada');
}
