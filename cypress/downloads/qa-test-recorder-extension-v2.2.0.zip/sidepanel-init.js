
// Sidepanel Initialization - Arquivo separado para evitar CSP
console.log('🏗️ SIDEPANEL-INIT: === INICIANDO CARREGAMENTO - SEM CSP ISSUES ===');

// Função para aguardar elementos existirem
function waitForElements() {
  return new Promise((resolve) => {
    const checkElements = () => {
      const loginInterface = document.getElementById('loginInterface');
      const recorderInterface = document.getElementById('recorderInterface');
      
      if (loginInterface && recorderInterface) {
        console.log('✅ SIDEPANEL-INIT: Elementos encontrados, prosseguindo...');
        resolve(true);
      } else {
        console.log('⏳ SIDEPANEL-INIT: Aguardando elementos existirem...');
        setTimeout(checkElements, 50);
      }
    };
    checkElements();
  });
}

// CRÍTICO: FORÇAR TELA DE LOGIN IMEDIATAMENTE
async function forceLoginScreenImmediately() {
  console.log('🔒 === FORÇANDO TELA DE LOGIN IMEDIATAMENTE - SEM CSP ===');
  
  // Aguardar elementos existirem
  await waitForElements();
  
  const loginInterface = document.getElementById('loginInterface');
  const recorderInterface = document.getElementById('recorderInterface');
  
  if (!loginInterface || !recorderInterface) {
    console.error('❌ SIDEPANEL-INIT: Elementos ainda não encontrados após aguardar!');
    return;
  }
  
  // Primeiro esconder QUALQUER interface de gravação
  recorderInterface.style.display = 'none';
  recorderInterface.style.visibility = 'hidden';
  recorderInterface.style.opacity = '0';
  recorderInterface.classList.remove('active');
  console.log('✅ INTERFACE DE GRAVAÇÃO FORÇADA A FICAR OCULTA');
  
  // Agora mostrar login
  loginInterface.style.display = 'flex';
  loginInterface.style.visibility = 'visible';
  loginInterface.style.opacity = '1';
  console.log('✅ INTERFACE DE LOGIN FORÇADA A APARECER');
  
  // Esconder qualquer elemento da interface antiga que possa estar aparecendo
  const oldMainContainer = document.querySelector('.main-container');
  if (oldMainContainer) {
    oldMainContainer.style.display = 'none';
    oldMainContainer.style.visibility = 'hidden';
    console.log('✅ CONTAINER ANTIGO OCULTADO');
  }
  
  console.log('🔒 === LOGIN SCREEN ENFORCEMENT COMPLETO ===');
}

// Verificar se elementos existem
function verifyElementsExist() {
  const loginInterface = document.getElementById('loginInterface');
  const recorderInterface = document.getElementById('recorderInterface');
  
  console.log('🔍 SIDEPANEL-INIT: Verificando elementos:', {
    loginInterface: !!loginInterface,
    recorderInterface: !!recorderInterface
  });
  
  if (loginInterface && recorderInterface) {
    console.log('✅ SIDEPANEL-INIT: Todos os elementos foram encontrados');
    return true;
  } else {
    console.error('❌ SIDEPANEL-INIT: Elementos não encontrados!');
    return false;
  }
}

// Garantir que login esteja visível
function ensureLoginVisible() {
  console.log('🔒 SIDEPANEL-INIT: === GARANTINDO QUE LOGIN ESTEJA VISÍVEL ===');
  
  const loginInterface = document.getElementById('loginInterface');
  const recorderInterface = document.getElementById('recorderInterface');
  
  if (loginInterface) {
    loginInterface.style.display = 'flex';
    loginInterface.style.visibility = 'visible';
    loginInterface.style.opacity = '1';
    console.log('✅ SIDEPANEL-INIT: Interface de login FORÇADA A APARECER');
  }
  
  if (recorderInterface) {
    recorderInterface.style.display = 'none';
    recorderInterface.style.visibility = 'hidden';
    recorderInterface.style.opacity = '0';
    console.log('✅ SIDEPANEL-INIT: Interface de gravação FORÇADA A FICAR OCULTA');
  }
}

// Carregar script principal
function loadMainScript() {
  return new Promise((resolve, reject) => {
    // Verificar se o script já foi carregado
    if (window.ExtensionMain) {
      console.log('⚠️ SIDEPANEL-INIT: ExtensionMain já existe');
      resolve();
      return;
    }
    
    const script = document.createElement('script');
    script.src = 'extension-sidepanel.js';
    script.onload = () => {
      console.log('✅ SIDEPANEL-INIT: Script principal carregado com sucesso');
      resolve();
    };
    script.onerror = (error) => {
      console.error('❌ SIDEPANEL-INIT: Erro ao carregar script principal:', error);
      reject(error);
    };
    document.head.appendChild(script);
  });
}

// Aguardar DOM estar pronto
function waitForDOMAndInitialize() {
  console.log('⏳ SIDEPANEL-INIT: Aguardando DOM estar completamente pronto...');
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      console.log('📄 SIDEPANEL-INIT: DOM carregado via evento');
      setTimeout(initializeAfterDOM, 100);
    });
  } else {
    console.log('📄 SIDEPANEL-INIT: DOM já estava pronto');
    setTimeout(initializeAfterDOM, 100);
  }
}

// Inicializar após DOM estar pronto
async function initializeAfterDOM() {
  console.log('🎯 SIDEPANEL-INIT: === INICIALIZANDO APÓS DOM PRONTO ===');
  
  if (!verifyElementsExist()) {
    console.error('💥 SIDEPANEL-INIT: Elementos não existem, tentando novamente...');
    setTimeout(initializeAfterDOM, 200);
    return;
  }
  
  await forceLoginScreenImmediately();
  
  // Aguardar mais um pouco e então carregar o script principal
  setTimeout(async () => {
    console.log('📦 SIDEPANEL-INIT: Carregando script principal...');
    try {
      await loadMainScript();
    } catch (error) {
      console.error('💥 SIDEPANEL-INIT: Erro ao carregar:', error);
    }
  }, 300);
}

// INICIAR o processo
waitForDOMAndInitialize();

// Garantir que login sempre esteja visível durante carregamento
const loginVisibilityInterval = setInterval(() => {
  if (document.getElementById('loginInterface')) {
    ensureLoginVisible();
  }
}, 500);

// Parar verificação após 10 segundos
setTimeout(() => {
  clearInterval(loginVisibilityInterval);
  console.log('⏹️ SIDEPANEL-INIT: Parando verificação contínua de visibilidade');
}, 10000);
