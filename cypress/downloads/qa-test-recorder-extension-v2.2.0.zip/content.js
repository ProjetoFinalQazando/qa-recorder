class TestRecorder {
  constructor() {
    this.isRecording = false;
    this.assertMode = false;
    this.currentUrl = window.location.href;
    this.steps = [];
    this.highlightedElement = null;
    this.overlay = null;
    this.isProcessingAssert = false;
    this.typingTimeout = null;
    this.lastTypedElement = null;
    this.listenersAttached = false;
    this.scrollTimeout = null;
    this.lastScrollY = window.scrollY;
    this.lastClickTime = 0;
    this.lastClickWasNavigation = false;
    
    this.initializeRecorder();
    this.setupMessageListener();
  }

  initializeRecorder() {
    console.log('QA Test Recorder: Content script loaded');
    this.createOverlay();
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((message) => {
      if (message.type === 'startRecording') {
        this.startRecording(message.assertMode);
      } else if (message.type === 'stopRecording') {
        this.stopRecording();
      } else if (message.type === 'updateAssertMode') {
        this.assertMode = message.assertMode;
      }
    });
  }

  createOverlay() {
    const existingOverlay = document.getElementById('qa-test-recorder-overlay');
    if (existingOverlay) {
      existingOverlay.remove();
    }

    this.overlay = document.createElement('div');
    this.overlay.id = 'qa-test-recorder-overlay';
    this.overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.1);
      pointer-events: none;
      z-index: 10000;
      display: none;
    `;
    document.body.appendChild(this.overlay);
  }

  updateOverlay(show) {
    if (this.overlay) {
      this.overlay.style.display = show ? 'block' : 'none';
    }
  }

  startRecording(assertMode) {
    if (this.isRecording) return;
    
    this.isRecording = true;
    this.assertMode = assertMode || false;
    this.steps = [];
    this.currentUrl = window.location.href;
    this.attachEventListeners();
    this.updateOverlay(true);
    console.log('🚀 Recording started!');
  }

  stopRecording() {
    this.isRecording = false;
    this.assertMode = false;
    this.removeEventListeners();
    this.clearHighlight();
    this.updateOverlay(false);
    this.isProcessingAssert = false;
    console.log('🛑 Recording stopped!');
  }

  attachEventListeners() {
    if (this.listenersAttached) return;
    
    this.boundHandleClick = this.handleClick.bind(this);
    this.boundHandleInput = this.handleInput.bind(this);
    this.boundHandleChange = this.handleChange.bind(this);
    this.boundHandleScroll = this.handleScroll.bind(this);
    this.boundHandleMouseOver = this.handleMouseOver.bind(this);
    this.boundHandleMouseOut = this.handleMouseOut.bind(this);
    this.boundHandleKeydown = this.handleKeydown.bind(this);

    document.addEventListener('click', this.boundHandleClick, true);
    document.addEventListener('input', this.boundHandleInput, true);
    document.addEventListener('change', this.boundHandleChange, true);
    document.addEventListener('scroll', this.boundHandleScroll, true);
    document.addEventListener('mouseover', this.boundHandleMouseOver, true);
    document.addEventListener('mouseout', this.boundHandleMouseOut, true);
    document.addEventListener('keydown', this.boundHandleKeydown, true);
    
    this.listenersAttached = true;
    console.log('📎 Event listeners attached');
  }

  removeEventListeners() {
    if (!this.listenersAttached) return;
    
    document.removeEventListener('click', this.boundHandleClick, true);
    document.removeEventListener('input', this.boundHandleInput, true);
    document.removeEventListener('change', this.boundHandleChange, true);
    document.removeEventListener('scroll', this.boundHandleScroll, true);
    document.removeEventListener('mouseover', this.boundHandleMouseOver, true);
    document.removeEventListener('mouseout', this.boundHandleMouseOut, true);
    document.removeEventListener('keydown', this.boundHandleKeydown, true);
    
    this.listenersAttached = false;
    console.log('🔗 Event listeners removed');
  }

  handleClick(event) {
    if (!this.isRecording || this.isRecorderElement(event.target)) return;

    if (this.assertMode) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      
      if (this.isProcessingAssert) return;
      this.handleAssert(event.target);
      return;
    }

    // Verificar se o clique pode causar navegação
    const willNavigate = this.willElementCauseNavigation(event.target);
    
    const selector = this.getElementSelector(event.target);
    const elementInfo = this.getElementInfo(event.target);

    this.recordStep({
      type: 'click',
      selector: selector,
      element: elementInfo.text,
      tagName: event.target.tagName.toLowerCase(),
      x: event.clientX,
      y: event.clientY
    });

    // Marcar que o último clique pode causar navegação
    if (willNavigate) {
      this.lastClickTime = Date.now();
      this.lastClickWasNavigation = true;
      
      // Resetar a flag após um tempo
      setTimeout(() => {
        this.lastClickWasNavigation = false;
      }, 2000);
    }

    this.flashElement(event.target, '#2196F3');
  }

  willElementCauseNavigation(element) {
    // Verificar se é um link
    if (element.tagName.toLowerCase() === 'a' && element.href) {
      return true;
    }
    
    // Verificar se é um botão que pode submeter um formulário
    if (element.tagName.toLowerCase() === 'button' && element.type === 'submit') {
      return true;
    }
    
    // Verificar se tem onclick que pode causar navegação
    if (element.onclick || element.getAttribute('onclick')) {
      const onclickStr = element.onclick ? element.onclick.toString() : element.getAttribute('onclick');
      if (onclickStr.includes('location') || onclickStr.includes('href') || onclickStr.includes('navigate')) {
        return true;
      }
    }
    
    // Verificar se está dentro de um link
    const parentLink = element.closest('a[href]');
    if (parentLink) {
      return true;
    }
    
    return false;
  }

  handleInput(event) {
    if (!this.isRecording || this.isRecorderElement(event.target)) return;

    if (this.typingTimeout) {
      clearTimeout(this.typingTimeout);
    }

    this.lastTypedElement = event.target;

    this.typingTimeout = setTimeout(() => {
      const selector = this.getElementSelector(event.target);
      const elementInfo = this.getElementInfo(event.target);

      this.recordStep({
        type: 'type',
        selector: selector,
        element: elementInfo.text,
        tagName: event.target.tagName.toLowerCase(),
        value: event.target.value,
        text: event.target.value
      });

      this.flashElement(event.target, '#FF9800');
      
      this.lastTypedElement = null;
      this.typingTimeout = null;
    }, 1000);
  }

  handleChange(event) {
    if (!this.isRecording || this.isRecorderElement(event.target)) return;

    const selector = this.getElementSelector(event.target);
    const elementInfo = this.getElementInfo(event.target);

    if (event.target.type === 'checkbox' || event.target.type === 'radio') {
      this.recordStep({
        type: event.target.type === 'checkbox' ? 'check' : 'radio',
        selector: selector,
        element: elementInfo.text,
        tagName: event.target.tagName.toLowerCase(),
        checked: event.target.checked,
        value: event.target.value
      });
    } else if (event.target.tagName.toLowerCase() === 'select') {
      this.recordStep({
        type: 'select',
        selector: selector,
        element: elementInfo.text,
        tagName: event.target.tagName.toLowerCase(),
        value: event.target.value,
        text: event.target.options[event.target.selectedIndex]?.text
      });
    }

    this.flashElement(event.target, '#9C27B0');
  }

  handleScroll(event) {
    if (!this.isRecording) return;

    clearTimeout(this.scrollTimeout);
    this.scrollTimeout = setTimeout(() => {
      this.recordStep({
        type: 'scroll',
        x: window.scrollX,
        y: window.scrollY,
        direction: this.lastScrollY < window.scrollY ? 'down' : 'up'
      });
      this.lastScrollY = window.scrollY;
    }, 300);
  }

  handleKeydown(event) {
    if (!this.isRecording || this.isRecorderElement(event.target)) return;

    if (event.key === 'Enter' || event.key === 'Tab' || event.key === 'Escape') {
      const selector = this.getElementSelector(event.target);
      const elementInfo = this.getElementInfo(event.target);

      this.recordStep({
        type: 'keypress',
        selector: selector,
        element: elementInfo.text,
        tagName: event.target.tagName.toLowerCase(),
        key: event.key,
        code: event.code
      });

      this.flashElement(event.target, '#E91E63');
    }
  }

  handleMouseOver(event) {
    if (!this.isRecording || this.isRecorderElement(event.target)) return;
    this.highlightElement(event.target, 'rgba(255, 255, 0, 0.3)');
  }

  handleMouseOut(event) {
    if (!this.isRecording) return;
    this.clearHighlight(event.target);
  }

  handleAssert(element) {
    if (this.isProcessingAssert) return;
    this.isProcessingAssert = true;

    try {
      const selector = this.getElementSelector(element);
      const elementInfo = this.getElementInfo(element);

      const assertionType = prompt(
        `Escolha o tipo de assertion para "${elementInfo.text}":\n\n` +
        '1. exist (elemento existe)\n' +
        '2. visible (elemento visível)\n' +
        '3. contain (contém texto)\n' +
        '4. have.value (tem valor)\n' +
        '5. have.class (tem classe)\n' +
        '6. be.enabled (está habilitado)\n' +
        '7. be.disabled (está desabilitado)\n\n' +
        'Digite o número da opção:'
      );

      if (assertionType === null || assertionType === '') {
        return;
      }

      const assertions = {
        '1': 'exist',
        '2': 'be.visible',
        '3': 'contain',
        '4': 'have.value',
        '5': 'have.class',
        '6': 'be.enabled',
        '7': 'be.disabled'
      };

      const assertion = assertions[assertionType];
      if (assertion) {
        let expectedValue = '';
        
        if (assertion === 'contain' || assertion === 'have.value' || assertion === 'have.class') {
          expectedValue = prompt(`Digite o valor esperado para "${assertion}":`);
          
          if (expectedValue === null) {
            return;
          }
        }

        this.recordStep({
          type: 'assert',
          selector: selector,
          assertion: assertion,
          expectedValue: expectedValue,
          element: elementInfo.text
        });

        this.flashElement(element, '#4CAF50');
      }
    } finally {
      setTimeout(() => {
        this.isProcessingAssert = false;
      }, 100);
    }
  }

  getElementSelector(element) {
    if (element.id) {
      return `#${element.id}`;
    }
    
    if (element.getAttribute('data-testid')) {
      return `[data-testid="${element.getAttribute('data-testid')}"]`;
    }

    if (element.classList && element.classList.length > 0) {
      const classes = Array.from(element.classList).join('.');
      const classSelector = `.${classes}`;
      
      if (document.querySelectorAll(classSelector).length === 1) {
        return classSelector;
      }
    }

    if (element.name) {
      return `[name="${element.name}"]`;
    }

    if (element.getAttribute('aria-label')) {
      return `[aria-label="${element.getAttribute('aria-label')}"]`;
    }

    const parent = element.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children);
      const index = siblings.indexOf(element) + 1;
      const parentSelector = this.getElementSelector(parent);
      return `${parentSelector} > ${element.tagName.toLowerCase()}:nth-child(${index})`;
    }

    return element.tagName.toLowerCase();
  }

  getElementInfo(element) {
    let text = '';
    
    if (element.textContent && element.textContent.trim()) {
      text = element.textContent.trim().substring(0, 30);
    } else if (element.placeholder) {
      text = `placeholder: ${element.placeholder}`;
    } else if (element.title) {
      text = `title: ${element.title}`;
    } else if (element.alt) {
      text = `alt: ${element.alt}`;
    } else if (element.value && element.type !== 'password') {
      text = `value: ${element.value}`;
    } else if (element.getAttribute('aria-label')) {
      text = `aria-label: ${element.getAttribute('aria-label')}`;
    } else {
      text = element.tagName.toLowerCase();
    }

    return { text: text || 'elemento' };
  }

  highlightElement(element, color) {
    if (this.highlightedElement && this.highlightedElement !== element) {
      this.clearHighlight();
    }

    this.highlightedElement = element;
    this.originalBackgroundColor = element.style.backgroundColor;
    this.originalOutline = element.style.outline;
    element.style.backgroundColor = color;
    element.style.outline = '2px solid #ffeb3b';
  }

  clearHighlight() {
    if (this.highlightedElement) {
      this.highlightedElement.style.backgroundColor = this.originalBackgroundColor || '';
      this.highlightedElement.style.outline = this.originalOutline || '';
      this.highlightedElement = null;
    }
  }

  flashElement(element, color) {
    const originalColor = element.style.backgroundColor;
    const originalOutline = element.style.outline;
    
    element.style.backgroundColor = color;
    element.style.outline = `2px solid ${color}`;
    
    setTimeout(() => {
      element.style.backgroundColor = originalColor;
      element.style.outline = originalOutline;
    }, 300);
  }

  isRecorderElement(element) {
    return element.id === 'qa-test-recorder-overlay' || 
           element.closest('#qa-test-recorder-overlay');
  }

  recordStep(step) {
    step.url = window.location.href;
    step.timestamp = Date.now();
    step.id = this.generateId();
    
    this.steps.push(step);

    chrome.runtime.sendMessage({
      type: 'stepRecorded',
      step: step
    }).catch(error => {
      console.log('Error sending step to background:', error);
    });

    console.log('Step recorded:', step);
  }

  generateId() {
    return Math.random().toString(36).substr(2, 9);
  }
}

// Garantir que só há uma instância do recorder
if (!window.testRecorder) {
  window.testRecorder = new TestRecorder();
}

// Monitorar navegação e alterações de rota SPA
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    console.log('Page navigated to:', url);
    
    if (window.testRecorder && window.testRecorder.isRecording) {
      // Verificar se a navegação aconteceu logo após um clique que pode causar navegação
      const timeSinceLastClick = Date.now() - window.testRecorder.lastClickTime;
      const shouldSkipNavigation = window.testRecorder.lastClickWasNavigation && timeSinceLastClick < 1500;
      
      if (!shouldSkipNavigation) {
        window.testRecorder.recordStep({
          type: 'navigate',
          url: url,
          from: window.testRecorder.currentUrl
        });
      } else {
        console.log('🚫 Skipping navigation step - caused by previous click');
      }
      
      window.testRecorder.currentUrl = url;
    }
  }
}).observe(document, { subtree: true, childList: true });

// Lidar com eventos de carregamento da página
window.addEventListener('load', () => {
  console.log('QA Test Recorder: Page loaded');
});

// Lidar com eventos de antes de sair da página
window.addEventListener('beforeunload', () => {
  if (window.testRecorder && window.testRecorder.isRecording) {
    console.log('QA Test Recorder: Page unloading during recording');
  }
});
