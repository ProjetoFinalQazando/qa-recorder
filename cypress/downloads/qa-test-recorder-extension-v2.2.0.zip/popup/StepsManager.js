
class StepsManager {
  constructor(uiManager) {
    this.steps = [];
    this.uiManager = uiManager;
  }

  addStep(step) {
    this.steps.push({
      ...step,
      timestamp: Date.now(),
      id: this.generateId()
    });
    
    this.renderSteps();
    this.updateStepsCounter();
  }

  renderSteps() {
    this.uiManager.elements.stepsList.innerHTML = '';
    
    this.steps.slice(-10).forEach(step => {
      const stepElement = document.createElement('div');
      stepElement.className = 'step-item';
      
      const icon = document.createElement('div');
      icon.className = `step-icon ${step.type}`;
      icon.textContent = this.getStepIcon(step.type);
      
      const description = document.createElement('div');
      description.textContent = this.getStepDescription(step);
      
      stepElement.appendChild(icon);
      stepElement.appendChild(description);
      this.uiManager.elements.stepsList.appendChild(stepElement);
    });
  }

  getStepIcon(type) {
    const icons = {
      click: '👆',
      type: '⌨️',
      scroll: '🖱️',
      assert: '✅',
      navigate: '🔗'
    };
    return icons[type] || '•';
  }

  getStepDescription(step) {
    switch (step.type) {
      case 'click':
        return `Click em ${step.element || 'elemento'}`;
      case 'type':
        return `Digitou: "${step.text || ''}"`;
      case 'scroll':
        return `Scroll para ${step.direction || 'baixo'}`;
      case 'assert':
        return `Assert: ${step.assertion || 'elemento existe'}`;
      case 'navigate':
        return `Navegou para: ${step.url || ''}`;
      default:
        return `Ação: ${step.type}`;
    }
  }

  updateStepsCounter() {
    const count = this.steps.length;
    this.uiManager.elements.stepsCount.textContent = `${count} passo${count !== 1 ? 's' : ''} gravado${count !== 1 ? 's' : ''}`;
  }

  async clearSteps() {
    if (confirm('Tem certeza que deseja limpar todos os passos gravados?')) {
      this.steps = [];
      this.renderSteps();
      this.updateStepsCounter();
      return true;
    }
    return false;
  }

  generateId() {
    return Math.random().toString(36).substr(2, 9);
  }
}
