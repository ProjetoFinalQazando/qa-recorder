
class AuthManager {
  constructor() {
    this.userRole = 'free';
    this.canGenerate = true;
  }

  setupAuthListener(callback) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && (changes.supabaseSession || changes.qa_recorder_auth)) {
        console.log('Auth state changed, rechecking access');
        callback();
      }
    });
  }

  async checkAuthAndAccess() {
    try {
      const authResult = await chrome.storage.local.get(['qa_recorder_auth', 'supabaseSession']);
      
      if (!authResult.qa_recorder_auth?.token && !authResult.supabaseSession?.access_token) {
        console.log('No authenticated user found');
        return { authenticated: false, canGenerate: false, userRole: 'free' };
      }

      const token = authResult.qa_recorder_auth?.token || authResult.supabaseSession?.access_token;

      const response = await fetch('https://wgkqubeyrynygzkvoezq.supabase.co/functions/v1/track-generation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ action: 'check-limit' })
      });

      if (response.ok) {
        const data = await response.json();
        this.canGenerate = data.canGenerate;
        this.userRole = data.userRole;
        
        console.log('Access status:', {
          canGenerate: this.canGenerate,
          role: this.userRole,
          isExpired: data.isExpired,
          trialExpired: data.trialExpired
        });
        
        return {
          authenticated: true,
          canGenerate: this.canGenerate,
          userRole: this.userRole
        };
      } else {
        console.error('Failed to check user access');
        return { authenticated: false, canGenerate: false, userRole: 'free' };
      }
    } catch (error) {
      console.error('Error checking auth and access:', error);
      return { authenticated: false, canGenerate: false, userRole: 'free' };
    }
  }

  async recordGeneration(testType, stepsCount) {
    try {
      const authResult = await chrome.storage.local.get(['qa_recorder_auth', 'supabaseSession']);
      const token = authResult.qa_recorder_auth?.token || authResult.supabaseSession?.access_token;
      
      if (!token) {
        console.log('No token found for recording generation');
        return;
      }

      const response = await fetch('https://wgkqubeyrynygzkvoezq.supabase.co/functions/v1/track-generation', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          action: 'record-generation',
          testType,
          stepsCount
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        if (response.status === 403) {
          this.canGenerate = false;
          throw new Error('Access denied or subscription expired');
        }
      }
    } catch (error) {
      console.error('Error recording generation:', error);
      throw error;
    }
  }
}
