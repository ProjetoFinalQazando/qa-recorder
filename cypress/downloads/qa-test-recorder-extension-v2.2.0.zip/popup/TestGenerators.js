
class TestGenerators {
  static generateCypressTest(steps) {
    console.log('🎯 GERANDO CYPRESS TEST...');
    
    let code = `describe('Teste Automatizado', () => {
  it('Executa passos gravados', () => {\n`;

    steps.forEach((step, index) => {
      console.log(`🔄 Processando step ${index + 1}:`, step);
      
      switch (step.type) {
        case 'navigate':
          code += `    cy.visit('${step.url}');\n`;
          break;
        case 'click':
          if (step.selector) {
            code += `    cy.get('${step.selector}').click();\n`;
          } else if (step.text) {
            code += `    cy.contains('${step.text}').click();\n`;
          } else if (step.element) {
            code += `    cy.contains('${step.element}').click();\n`;
          } else {
            code += `    cy.get('button').click();\n`;
          }
          break;
        case 'type':
          if (step.selector && step.text) {
            code += `    cy.get('${step.selector}').clear().type('${step.text}');\n`;
          } else if (step.text) {
            code += `    cy.get('input').type('${step.text}');\n`;
          }
          break;
        case 'scroll':
          if (step.direction === 'top') {
            code += `    cy.scrollTo('top');\n`;
          } else {
            code += `    cy.scrollTo('bottom');\n`;
          }
          break;
        case 'assert':
          if (step.selector) {
            code += `    cy.get('${step.selector}').should('exist');\n`;
          } else if (step.text) {
            code += `    cy.contains('${step.text}').should('be.visible');\n`;
          } else {
            code += `    cy.get('body').should('exist');\n`;
          }
          break;
      }
    });

    code += `  });
});`;

    console.log('✅ CYPRESS CODE GERADO:', code);
    return code;
  }

  static generatePlaywrightTest(steps) {
    console.log('🎭 GERANDO PLAYWRIGHT TEST...');
    
    let code = `const { test, expect } = require('@playwright/test');

test('Teste Automatizado', async ({ page }) => {\n`;

    steps.forEach((step, index) => {
      console.log(`🔄 Processando step ${index + 1}:`, step);
      
      switch (step.type) {
        case 'navigate':
          code += `  await page.goto('${step.url}');\n`;
          break;
        case 'click':
          if (step.selector) {
            code += `  await page.click('${step.selector}');\n`;
          } else if (step.text) {
            code += `  await page.getByText('${step.text}').click();\n`;
          } else if (step.element) {
            code += `  await page.getByText('${step.element}').click();\n`;
          } else {
            code += `  await page.click('button');\n`;
          }
          break;
        case 'type':
          if (step.selector && step.text) {
            code += `  await page.fill('${step.selector}', '${step.text}');\n`;
          } else if (step.text) {
            code += `  await page.fill('input', '${step.text}');\n`;
          }
          break;
        case 'scroll':
          if (step.direction === 'top') {
            code += `  await page.evaluate(() => window.scrollTo(0, 0));\n`;
          } else {
            code += `  await page.evaluate(() => window.scrollTo(0, document.body.scrollHeight));\n`;
          }
          break;
        case 'assert':
          if (step.selector) {
            code += `  await expect(page.locator('${step.selector}')).toBeVisible();\n`;
          } else if (step.text) {
            code += `  await expect(page.getByText('${step.text}')).toBeVisible();\n`;
          } else {
            code += `  await expect(page.locator('body')).toBeVisible();\n`;
          }
          break;
      }
    });

    code += `});`;

    console.log('✅ PLAYWRIGHT CODE GERADO:', code);
    return code;
  }

  static generateRobotFrameworkTest(steps) {
    console.log('🤖 GERANDO ROBOT FRAMEWORK TEST...');
    
    let code = `*** Settings ***
Library    SeleniumLibrary

*** Variables ***
\${BROWSER}    chrome
\${DELAY}      0.5s

*** Test Cases ***
Teste Automatizado
    [Documentation]    Executa passos gravados automaticamente\n`;

    let browserOpened = false;

    steps.forEach((step, index) => {
      console.log(`🔄 Processando step ${index + 1}:`, step);
      
      switch (step.type) {
        case 'navigate':
          if (!browserOpened) {
            code += `    Open Browser    ${step.url}    \${BROWSER}\n`;
            code += `    Maximize Browser Window\n`;
            browserOpened = true;
          } else {
            code += `    Go To    ${step.url}\n`;
          }
          break;
        case 'click':
          if (step.selector) {
            if (step.selector.startsWith('#')) {
              code += `    Click Element    id=${step.selector.substring(1)}\n`;
            } else if (step.selector.startsWith('.')) {
              code += `    Click Element    class=${step.selector.substring(1)}\n`;
            } else {
              code += `    Click Element    css=${step.selector}\n`;
            }
          } else if (step.text || step.element) {
            const text = step.text || step.element;
            code += `    Click Element    xpath=//*[contains(text(),'${text}')]\n`;
          } else {
            code += `    Click Button    xpath=//button[1]\n`;
          }
          break;
        case 'type':
          if (step.selector && step.text) {
            if (step.selector.startsWith('#')) {
              code += `    Input Text    id=${step.selector.substring(1)}    ${step.text}\n`;
            } else if (step.selector.startsWith('.')) {
              code += `    Input Text    class=${step.selector.substring(1)}    ${step.text}\n`;
            } else {
              code += `    Input Text    css=${step.selector}    ${step.text}\n`;
            }
          } else if (step.text) {
            code += `    Input Text    xpath=//input[1]    ${step.text}\n`;
          }
          break;
        case 'scroll':
          if (step.direction === 'top') {
            code += `    Execute Javascript    window.scrollTo(0, 0)\n`;
          } else {
            code += `    Execute Javascript    window.scrollTo(0, document.body.scrollHeight)\n`;
          }
          break;
        case 'assert':
          if (step.selector) {
            if (step.selector.startsWith('#')) {
              code += `    Element Should Be Visible    id=${step.selector.substring(1)}\n`;
            } else if (step.selector.startsWith('.')) {
              code += `    Element Should Be Visible    class=${step.selector.substring(1)}\n`;
            } else {
              code += `    Element Should Be Visible    css=${step.selector}\n`;
            }
          } else if (step.text || step.element) {
            const text = step.text || step.element;
            code += `    Page Should Contain    ${text}\n`;
          } else {
            code += `    Page Should Contain Element    body\n`;
          }
          break;
      }
      code += `    Sleep    \${DELAY}\n`;
    });

    if (browserOpened) {
      code += `    Close Browser\n`;
    }

    console.log('✅ ROBOT FRAMEWORK CODE GERADO:', code);
    return code;
  }

  static generateSeleniumTest(steps) {
    console.log('🐍 GERANDO SELENIUM TEST...');
    
    let code = `from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import time

def test_automatizado():
    """Executa teste automatizado com passos gravados"""
    # Configurar driver
    options = webdriver.ChromeOptions()
    options.add_argument('--start-maximized')
    driver = webdriver.Chrome(options=options)
    wait = WebDriverWait(driver, 10)
    
    try:\n`;

    steps.forEach((step, index) => {
      console.log(`🔄 Processando step ${index + 1}:`, step);
      
      switch (step.type) {
        case 'navigate':
          code += `        driver.get('${step.url}')\n`;
          code += `        time.sleep(1)\n`;
          break;
        case 'click':
          if (step.selector) {
            const selector = TestGenerators.convertSelectorToPython(step.selector);
            code += `        element = wait.until(EC.element_to_be_clickable(${selector}))\n`;
            code += `        element.click()\n`;
          } else if (step.text || step.element) {
            const text = step.text || step.element;
            code += `        element = wait.until(EC.element_to_be_clickable((By.XPATH, "//*[contains(text(),'${text}')]")))\n`;
            code += `        element.click()\n`;
          } else {
            code += `        element = wait.until(EC.element_to_be_clickable((By.TAG_NAME, "button")))\n`;
            code += `        element.click()\n`;
          }
          break;
        case 'type':
          if (step.selector && step.text) {
            const selector = TestGenerators.convertSelectorToPython(step.selector);
            code += `        element = wait.until(EC.presence_of_element_located(${selector}))\n`;
            code += `        element.clear()\n`;
            code += `        element.send_keys('${step.text}')\n`;
          } else if (step.text) {
            code += `        element = wait.until(EC.presence_of_element_located((By.TAG_NAME, "input")))\n`;
            code += `        element.clear()\n`;
            code += `        element.send_keys('${step.text}')\n`;
          }
          break;
        case 'scroll':
          if (step.direction === 'top') {
            code += `        driver.execute_script("window.scrollTo(0, 0);")\n`;
          } else {
            code += `        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")\n`;
          }
          break;
        case 'assert':
          if (step.selector) {
            const selector = TestGenerators.convertSelectorToPython(step.selector);
            code += `        assert wait.until(EC.visibility_of_element_located(${selector}))\n`;
          } else if (step.text || step.element) {
            const text = step.text || step.element;
            code += `        assert '${text}' in driver.page_source\n`;
          } else {
            code += `        assert wait.until(EC.presence_of_element_located((By.TAG_NAME, "body")))\n`;
          }
          break;
      }
      code += `        time.sleep(0.5)\n`;
    });

    code += `    finally:
        driver.quit()

if __name__ == "__main__":
    test_automatizado()
    print("Teste executado com sucesso!")`;

    console.log('✅ SELENIUM CODE GERADO:', code);
    return code;
  }

  static convertSelectorToPython(selector) {
    if (!selector) return `(By.TAG_NAME, "body")`;
    
    if (selector.startsWith('#')) {
      return `(By.ID, '${selector.substring(1)}')`;
    } else if (selector.startsWith('.')) {
      return `(By.CLASS_NAME, '${selector.substring(1)}')`;
    } else if (selector.includes('[')) {
      return `(By.CSS_SELECTOR, '${selector}')`;
    } else if (selector.includes('//')) {
      return `(By.XPATH, '${selector}')`;
    } else {
      return `(By.CSS_SELECTOR, '${selector}')`;
    }
  }

  static getFileExtension(framework) {
    switch (framework) {
      case 'cypress':
        return 'cy.js';
      case 'playwright':
        return 'spec.js';
      case 'robot':
        return 'robot';
      case 'selenium':
        return 'py';
      default:
        return 'js';
    }
  }

  static downloadFile(filename, content) {
    console.log('💾 FAZENDO DOWNLOAD:', filename);
    console.log('📄 CONTEÚDO DO ARQUIVO:', content);
    
    const blob = new Blob([content], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    
    URL.revokeObjectURL(url);
  }
}
