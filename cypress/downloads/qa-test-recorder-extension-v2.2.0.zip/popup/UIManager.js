
class UIManager {
  constructor() {
    this.elements = {};
  }

  initializeElements() {
    this.elements = {
      recordButton: document.getElementById('recordButton'),
      recordIcon: document.getElementById('recordIcon'),
      recordText: document.getElementById('recordText'),
      status: document.getElementById('status'),
      assertToggle: document.getElementById('assertToggle'),
      stepsList: document.getElementById('stepsList'),
      stepsCount: document.getElementById('stepsCount'),
      clearButton: document.getElementById('clearButton'),
      exportCypress: document.getElementById('exportCypress'),
      exportPlaywright: document.getElementById('exportPlaywright'),
      exportRobot: document.getElementById('exportRobot'),
      exportSelenium: document.getElementById('exportSelenium')
    };
  }

  showNotLoggedIn() {
    this.disableAllButtons();
    this.showMessage('🔐 Faça login na aplicação web para usar a extensão', 'warning');
  }

  showAccessDenied(userRole) {
    this.disableAllButtons();

    let message;
    if (userRole === 'free') {
      message = '⏰ Seu período de teste gratuito de 3 dias expirou! Faça upgrade para Premium na aplicação web';
    } else if (userRole === 'mensal') {
      message = '💳 Sua assinatura mensal expirou. Renove seu plano na aplicação web';
    } else {
      message = '❌ Acesso negado. Verifique seu plano na aplicação web';
    }
    
    this.showMessage(message, 'error');
  }

  hideAccessMessage() {
    const existingMessage = document.getElementById('accessMessage');
    if (existingMessage) {
      existingMessage.remove();
    }
    
    this.enableAllButtons();
  }

  disableAllButtons() {
    const buttons = [
      this.elements.recordButton,
      this.elements.exportCypress,
      this.elements.exportPlaywright,
      this.elements.exportRobot,
      this.elements.exportSelenium
    ];

    buttons.forEach(btn => {
      btn.disabled = true;
      btn.style.opacity = '0.5';
      btn.style.cursor = 'not-allowed';
    });
  }

  enableAllButtons() {
    const buttons = [
      this.elements.recordButton,
      this.elements.exportCypress,
      this.elements.exportPlaywright,
      this.elements.exportRobot,
      this.elements.exportSelenium
    ];

    buttons.forEach(btn => {
      btn.disabled = false;
      btn.style.opacity = '1';
      btn.style.cursor = 'pointer';
    });
  }

  showMessage(message, type) {
    const existingMessage = document.getElementById('accessMessage');
    if (existingMessage) existingMessage.remove();

    const accessMessage = document.createElement('div');
    accessMessage.id = 'accessMessage';
    
    let backgroundColor, borderColor, textColor;
    switch (type) {
      case 'error':
        backgroundColor = '#fee2e2';
        borderColor = '#fecaca';
        textColor = '#991b1b';
        break;
      case 'warning':
        backgroundColor = '#fef3c7';
        borderColor = '#fde68a';
        textColor = '#92400e';
        break;
      default:
        backgroundColor = '#fee2e2';
        borderColor = '#fecaca';
        textColor = '#991b1b';
    }

    accessMessage.style.cssText = `
      background: ${backgroundColor};
      border: 1px solid ${borderColor};
      color: ${textColor};
      padding: 8px;
      border-radius: 6px;
      margin: 8px 0;
      text-align: center;
      font-size: 12px;
    `;
    accessMessage.innerHTML = `<strong>${message}</strong>`;

    const controls = document.querySelector('.controls');
    if (controls) {
      controls.insertBefore(accessMessage, controls.firstChild);
    }
  }

  updateUI(isRecording, assertMode) {
    if (isRecording) {
      this.elements.recordButton.className = 'record-button stop';
      this.elements.recordIcon.textContent = '⏹️';
      this.elements.recordText.textContent = 'Parar Gravação';
      this.elements.status.className = 'status recording';
      this.elements.status.textContent = 'Status: Gravando...';
    } else {
      this.elements.recordButton.className = 'record-button start';
      this.elements.recordIcon.textContent = '⏺️';
      this.elements.recordText.textContent = 'Iniciar Gravação';
      this.elements.status.className = 'status stopped';
      this.elements.status.textContent = 'Status: Parado';
    }

    this.elements.assertToggle.classList.toggle('active', assertMode);
  }

  showUpgradePrompt(userRole) {
    if (userRole === 'free') {
      alert('⏰ Seu período de teste gratuito de 3 dias expirou! Faça upgrade para Premium na aplicação web para continuar.');
    } else if (userRole === 'mensal') {
      alert('💳 Sua assinatura mensal expirou. Acesse a aplicação web para renovar.');
    } else {
      alert('❌ Acesso negado. Verifique seu plano na aplicação web.');
    }
  }

  showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.style.cssText = `
      position: fixed;
      top: 10px;
      left: 10px;
      right: 10px;
      background: #f44336;
      color: white;
      padding: 10px;
      border-radius: 5px;
      z-index: 10000;
    `;
    errorDiv.textContent = message;
    document.body.appendChild(errorDiv);
    
    setTimeout(() => {
      document.body.removeChild(errorDiv);
    }, 3000);
  }
}
