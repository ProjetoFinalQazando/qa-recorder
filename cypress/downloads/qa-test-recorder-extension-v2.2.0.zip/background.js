class QARecorderBackground {
  constructor() {
    this.currentSidepanelTab = null; // Rastrear qual aba tem o sidepanel aberto
    this.lastNavigationTime = new Map(); // Rastrear últimas navegações por aba
    this.navigationClicksDetected = new Map(); // Rastrear cliques que vão causar navegação
    this.preventedNavigations = new Set(); // Para rastrear navegações que devem ser ignoradas
    this.initializeExtension();
  }

  initializeExtension() {
    console.log('🚀 QA Test Recorder: Service worker iniciado');
    
    chrome.runtime.onInstalled.addListener((details) => {
      this.handleInstallation(details);
    });

    chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
      this.handleTabUpdate(tabId, changeInfo, tab);
    });

    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
      this.handleMessage(message, sender, sendResponse);
    });

    // Controlar abertura do sidepanel para uma aba específica
    chrome.action.onClicked.addListener(async (tab) => {
      try {
        // Se já existe um sidepanel aberto em outra aba, fechar
        if (this.currentSidepanelTab && this.currentSidepanelTab !== tab.id) {
          await chrome.sidePanel.setOptions({ 
            tabId: this.currentSidepanelTab, 
            enabled: false 
          });
        }

        // Abrir sidepanel apenas na aba atual
        await chrome.sidePanel.open({ windowId: tab.windowId });
        await chrome.sidePanel.setOptions({ 
          tabId: tab.id, 
          path: 'sidepanel.html', 
          enabled: true 
        });

        this.currentSidepanelTab = tab.id;
        console.log(`📱 Sidepanel aberto na aba ${tab.id}`);

        // Salvar referência da aba ativa
        await chrome.storage.local.set({
          activeSidepanelTab: tab.id,
          sidepanelWindowId: tab.windowId
        });

      } catch (error) {
        console.error('Erro ao abrir sidepanel:', error);
      }
    });

    // Monitorar fechamento de abas
    chrome.tabs.onRemoved.addListener((tabId) => {
      if (this.currentSidepanelTab === tabId) {
        this.currentSidepanelTab = null;
        chrome.storage.local.remove(['activeSidepanelTab', 'sidepanelWindowId']);
        console.log(`📱 Sidepanel fechado - aba ${tabId} removida`);
      }
      
      // Limpar dados da aba
      this.lastNavigationTime.delete(tabId);
      this.navigationClicksDetected.delete(tabId);
      this.preventedNavigations.delete(tabId);
    });
  }

  handleInstallation(details) {
    if (details.reason === 'install') {
      console.log('🎉 QA Test Recorder: Extensão instalada com sucesso');
      
      chrome.storage.local.set({
        isRecording: false,
        assertMode: false,
        steps: [],
        activeSidepanelTab: null,
        settings: {
          autoStart: false,
          showOverlay: true,
          generateComments: true
        }
      });
    } else if (details.reason === 'update') {
      console.log('🔄 QA Test Recorder: Extensão atualizada');
    }
  }

  handleTabUpdate(tabId, changeInfo, tab) {
    if (changeInfo.status === 'complete' && tab.url) {
      this.handlePageNavigation(tabId, tab.url);
    }
  }

  async handlePageNavigation(tabId, url) {
    try {
      const result = await chrome.storage.local.get(['isRecording', 'activeSidepanelTab', 'steps']);
      
      // Só processar navegação se for a aba ativa do sidepanel
      if (result.isRecording && result.activeSidepanelTab === tabId) {
        const now = Date.now();
        
        // Verificar se esta navegação deve ser ignorada (causada por clique)
        if (this.preventedNavigations.has(tabId)) {
          console.log('🚫 Skipping navigation - caused by navigation click');
          this.preventedNavigations.delete(tabId);
          return;
        }
        
        const lastNavTime = this.lastNavigationTime.get(tabId) || 0;
        const timeSinceLastNav = now - lastNavTime;
        
        // Evitar múltiplas navegações muito próximas
        if (timeSinceLastNav < 2000) {
          console.log('🚫 Skipping rapid navigation - too close to previous navigation');
          return;
        }
        
        // Verificar se temos um clique de navegação detectado recentemente
        const navigationClick = this.navigationClicksDetected.get(tabId);
        if (navigationClick && (now - navigationClick.timestamp) < 3000) {
          console.log('🚫 Skipping navigation step - caused by detected navigation click');
          this.lastNavigationTime.set(tabId, now);
          this.navigationClicksDetected.delete(tabId);
          return;
        }
        
        const steps = result.steps || [];
        const lastStep = steps[steps.length - 1];
        
        // Verificar se o último step foi um clique que pode ter causado navegação
        if (lastStep && lastStep.type === 'click' && lastStep.willNavigate && (now - lastStep.timestamp) < 3000) {
          console.log('🚫 Skipping navigation step - likely caused by previous click with willNavigate=true');
          this.lastNavigationTime.set(tabId, now);
          return;
        }

        // Só gravar navegação se não foi causada por clique
        const step = {
          type: 'navigate',
          url: url,
          timestamp: now,
          id: this.generateId(),
          tabId: tabId
        };

        steps.push(step);
        await chrome.storage.local.set({ steps: steps });
        this.lastNavigationTime.set(tabId, now);

        // Notificar apenas se for a aba do sidepanel
        chrome.runtime.sendMessage({
          type: 'stepRecorded',
          step: step
        }).catch(() => {
          console.log('Sidepanel não está aberto para receber mensagem');
        });
      }
    } catch (error) {
      console.error('Error handling page navigation:', error);
    }
  }

  handleMessage(message, sender, sendResponse) {
    switch (message.type) {
      case 'stepRecorded':
        this.handleStepRecorded(message.step, sender);
        break;
        
      case 'navigationClickDetected':
        this.handleNavigationClickDetected(message, sender);
        break;
        
      case 'getRecordingState':
        this.getRecordingState(sendResponse);
        break;
        
      case 'updateSettings':
        this.updateSettings(message.settings, sendResponse);
        break;

      case 'setSidepanelTab':
        this.currentSidepanelTab = message.tabId;
        break;
        
      default:
        console.log('Unknown message type:', message.type);
    }
    
    return true;
  }

  handleNavigationClickDetected(message, sender) {
    if (sender.tab) {
      console.log('🔗 Navigation click detected from content script:', message);
      
      // Se tem flag preventNavigation, marcar para ignorar próxima navegação
      if (message.preventNavigation) {
        this.preventedNavigations.add(sender.tab.id);
        console.log('🚫 Navigation prevention flag set for tab:', sender.tab.id);
        
        // Limpar flag após 5 segundos
        setTimeout(() => {
          this.preventedNavigations.delete(sender.tab.id);
          console.log('🔄 Navigation prevention flag cleared for tab:', sender.tab.id);
        }, 5000);
      }
      
      this.navigationClicksDetected.set(sender.tab.id, {
        selector: message.selector,
        timestamp: message.timestamp,
        url: message.url
      });
      
      setTimeout(() => {
        this.navigationClicksDetected.delete(sender.tab.id);
      }, 5000);
    }
  }

  async handleStepRecorded(step, sender) {
    try {
      const result = await chrome.storage.local.get(['steps', 'activeSidepanelTab']);
      
      if (result.activeSidepanelTab && sender.tab?.id === result.activeSidepanelTab) {
        const steps = result.steps || [];
        
        steps.push({
          ...step,
          timestamp: Date.now(),
          id: this.generateId(),
          tabId: sender.tab?.id,
          url: sender.tab?.url
        });

        await chrome.storage.local.set({ steps: steps });
        console.log('📝 Step saved to storage:', step);
      }
    } catch (error) {
      console.error('Error saving step:', error);
    }
  }

  async getRecordingState(sendResponse) {
    try {
      const result = await chrome.storage.local.get([
        'isRecording', 
        'assertMode', 
        'steps',
        'settings',
        'activeSidepanelTab'
      ]);
      
      sendResponse({
        success: true,
        data: result
      });
    } catch (error) {
      sendResponse({
        success: false,
        error: error.message
      });
    }
  }

  async updateSettings(settings, sendResponse) {
    try {
      await chrome.storage.local.set({ settings: settings });
      
      sendResponse({
        success: true,
        message: 'Settings updated successfully'
      });
    } catch (error) {
      sendResponse({
        success: false,
        error: error.message
      });
    }
  }

  generateId() {
    return Math.random().toString(36).substr(2, 9);
  }
}

const qaRecorderBackground = new QARecorderBackground();

chrome.runtime.onSuspend.addListener(() => {
  console.log('🛑 QA Test Recorder: Service worker suspending');
});

chrome.runtime.onStartup.addListener(() => {
  console.log('🔄 QA Test Recorder: Service worker starting up');
});
