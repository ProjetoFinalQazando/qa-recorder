
class TestRecorderPopup {
  constructor() {
    this.isRecording = false;
    this.assertMode = false;
    this.authManager = new AuthManager();
    this.uiManager = new UIManager();
    this.stepsManager = new StepsManager(this.uiManager);
    this.initialize();
  }

  async initialize() {
    this.uiManager.initializeElements();
    this.attachEventListeners();
    await this.loadState();
    await this.checkAuthAndAccess();
    this.authManager.setupAuthListener(() => this.checkAuthAndAccess());
  }

  async checkAuthAndAccess() {
    const result = await this.authManager.checkAuthAndAccess();
    
    if (!result.authenticated) {
      this.uiManager.showNotLoggedIn();
    } else if (!result.canGenerate) {
      this.uiManager.showAccessDenied(result.userRole);
    } else {
      this.uiManager.hideAccessMessage();
    }
  }

  attachEventListeners() {
    this.uiManager.elements.recordButton.addEventListener('click', () => {
      if (this.uiManager.elements.recordButton.disabled) {
        this.uiManager.showUpgradePrompt(this.authManager.userRole);
        return;
      }
      this.toggleRecording();
    });
    
    this.uiManager.elements.assertToggle.addEventListener('click', () => this.toggleAssertMode());
    this.uiManager.elements.clearButton.addEventListener('click', () => this.clearSteps());
    
    this.uiManager.elements.exportCypress.addEventListener('click', () => {
      if (this.uiManager.elements.exportCypress.disabled) {
        this.uiManager.showUpgradePrompt(this.authManager.userRole);
        return;
      }
      this.exportTest('cypress');
    });
    
    this.uiManager.elements.exportPlaywright.addEventListener('click', () => {
      if (this.uiManager.elements.exportPlaywright.disabled) {
        this.uiManager.showUpgradePrompt(this.authManager.userRole);
        return;
      }
      this.exportTest('playwright');
    });

    this.uiManager.elements.exportRobot.addEventListener('click', () => {
      if (this.uiManager.elements.exportRobot.disabled) {
        this.uiManager.showUpgradePrompt(this.authManager.userRole);
        return;
      }
      this.exportTest('robot');
    });

    this.uiManager.elements.exportSelenium.addEventListener('click', () => {
      if (this.uiManager.elements.exportSelenium.disabled) {
        this.uiManager.showUpgradePrompt(this.authManager.userRole);
        return;
      }
      this.exportTest('selenium');
    });

    chrome.runtime.onMessage.addListener((message) => {
      if (message.type === 'stepRecorded') {
        this.stepsManager.addStep(message.step);
        this.saveState();
      } else if (message.type === 'accessUpdated') {
        this.checkAuthAndAccess();
      }
    });
  }

  async loadState() {
    try {
      const result = await chrome.storage.local.get(['isRecording', 'assertMode', 'steps']);
      
      this.isRecording = result.isRecording || false;
      this.assertMode = result.assertMode || false;
      this.stepsManager.steps = result.steps || [];

      this.updateUI();
      this.stepsManager.renderSteps();
    } catch (error) {
      console.error('Error loading state:', error);
    }
  }

  async saveState() {
    try {
      await chrome.storage.local.set({
        isRecording: this.isRecording,
        assertMode: this.assertMode,
        steps: this.stepsManager.steps
      });
    } catch (error) {
      console.error('Error saving state:', error);
    }
  }

  async toggleRecording() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (this.isRecording) {
        await chrome.tabs.sendMessage(tab.id, { 
          type: 'stopRecording' 
        });
        this.isRecording = false;
        this.updateUI();
      } else {
        await chrome.tabs.sendMessage(tab.id, { 
          type: 'startRecording',
          assertMode: this.assertMode
        });
        this.isRecording = true;
        this.updateUI();
      }
      
      await this.saveState();
    } catch (error) {
      console.error('Error toggling recording:', error);
      this.uiManager.showError('Erro ao alterar gravação. Recarregue a página e tente novamente.');
    }
  }

  async toggleAssertMode() {
    this.assertMode = !this.assertMode;
    
    if (this.isRecording) {
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        await chrome.tabs.sendMessage(tab.id, { 
          type: 'updateAssertMode',
          assertMode: this.assertMode
        });
      } catch (error) {
        console.error('Error updating assert mode:', error);
      }
    }
    
    this.updateUI();
    await this.saveState();
  }

  updateUI() {
    this.uiManager.updateUI(this.isRecording, this.assertMode);
    this.stepsManager.updateStepsCounter();
  }

  async clearSteps() {
    const cleared = await this.stepsManager.clearSteps();
    if (cleared) {
      await this.saveState();
    }
  }

  async exportTest(framework) {
    console.log('🚀 EXPORT TEST INICIADO:', framework);
    console.log('📊 STEPS DISPONÍVEIS:', this.stepsManager.steps.length);
    console.log('🔍 STEPS DETALHADOS:', this.stepsManager.steps);

    if (this.stepsManager.steps.length === 0) {
      alert('📝 Nenhum passo foi gravado ainda! Grave algumas ações primeiro.');
      return;
    }

    await this.checkAuthAndAccess();
    
    if (!this.authManager.canGenerate) {
      if (this.authManager.userRole === 'free') {
        alert('⏰ Período de teste expirado! Faça upgrade para Premium na aplicação web.');
      } else if (this.authManager.userRole === 'mensal') {
        alert('💳 Sua assinatura mensal expirou. Renove seu plano na aplicação web.');
      } else {
        alert('❌ Acesso negado. Verifique seu plano na aplicação web.');
      }
      return;
    }

    try {
      await this.authManager.recordGeneration(framework, this.stepsManager.steps.length);
    } catch (error) {
      if (error.message.includes('Access denied')) {
        this.uiManager.showAccessDenied(this.authManager.userRole);
        alert('Acesso negado ou assinatura expirada!');
      }
      return;
    }

    let testCode;
    console.log('🛠️ GERANDO CÓDIGO PARA:', framework);
    
    switch (framework) {
      case 'cypress':
        testCode = TestGenerators.generateCypressTest(this.stepsManager.steps);
        break;
      case 'playwright':
        testCode = TestGenerators.generatePlaywrightTest(this.stepsManager.steps);
        break;
      case 'robot':
        testCode = TestGenerators.generateRobotFrameworkTest(this.stepsManager.steps);
        break;
      case 'selenium':
        testCode = TestGenerators.generateSeleniumTest(this.stepsManager.steps);
        break;
      default:
        testCode = TestGenerators.generateCypressTest(this.stepsManager.steps);
    }

    console.log('✅ CÓDIGO GERADO:', testCode);

    const fileExtension = TestGenerators.getFileExtension(framework);
    TestGenerators.downloadFile(`test.${fileExtension}`, testCode);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  new TestRecorderPopup();
});
