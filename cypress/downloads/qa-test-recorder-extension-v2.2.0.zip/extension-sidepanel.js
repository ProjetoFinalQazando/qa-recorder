
// Extension Sidepanel Main Script - VERSÃO FINAL CORRIGIDA
console.log('🚀 === EXTENSION SIDEPANEL INICIANDO - VERSÃO FINAL CORRIGIDA ===');

// Função para aguardar elementos existirem
function waitForElements() {
  return new Promise((resolve) => {
    const checkElements = () => {
      const loginInterface = document.getElementById('loginInterface');
      const recorderInterface = document.getElementById('recorderInterface');
      
      if (loginInterface && recorderInterface) {
        console.log('✅ EXTENSION-SIDEPANEL: Elementos encontrados, prosseguindo...');
        resolve(true);
      } else {
        console.log('⏳ EXTENSION-SIDEPANEL: Aguardando elementos existirem...');
        setTimeout(checkElements, 50);
      }
    };
    checkElements();
  });
}

// CRÍTICO: FORÇAR TELA DE LOGIN IMEDIATAMENTE, MAS APENAS SE ELEMENTOS EXISTIREM
async function forceLoginScreenImmediately() {
  console.log('🔒 === FORÇANDO TELA DE LOGIN IMEDIATAMENTE - VERSÃO FINAL ===');
  
  // Aguardar elementos existirem
  await waitForElements();
  
  const loginInterface = document.getElementById('loginInterface');
  const recorderInterface = document.getElementById('recorderInterface');
  
  if (!loginInterface || !recorderInterface) {
    console.error('❌ EXTENSION-SIDEPANEL: Elementos ainda não encontrados após aguardar!');
    return;
  }
  
  // Primeiro esconder QUALQUER interface de gravação
  recorderInterface.style.display = 'none';
  recorderInterface.style.visibility = 'hidden';
  recorderInterface.style.opacity = '0';
  recorderInterface.classList.remove('active');
  console.log('✅ INTERFACE DE GRAVAÇÃO FORÇADA A FICAR OCULTA');
  
  // Agora mostrar login
  loginInterface.style.display = 'flex';
  loginInterface.style.visibility = 'visible';
  loginInterface.style.opacity = '1';
  console.log('✅ INTERFACE DE LOGIN FORÇADA A APARECER');
  
  // Esconder qualquer elemento da interface antiga que possa estar aparecendo
  const oldMainContainer = document.querySelector('.main-container');
  if (oldMainContainer) {
    oldMainContainer.style.display = 'none';
    oldMainContainer.style.visibility = 'hidden';
    console.log('✅ CONTAINER ANTIGO OCULTADO');
  }
  
  console.log('🔒 === LOGIN SCREEN ENFORCEMENT COMPLETO ===');
}

async function loadExtensionModules() {
  try {
    console.log('📦 CARREGANDO MÓDULOS - aguardando elementos primeiro...');
    
    // ANTES de carregar qualquer módulo, aguardar elementos e garantir que login está visível
    await waitForElements();
    await forceLoginScreenImmediately();
    
    // Carregar os módulos necessários na ordem correta
    const modules = [
      'sidepanel/ui/UIManager.js',
      'sidepanel/ui/FormManager.js',
      'sidepanel/ui/ModuleLoader.js',
      'sidepanel/ui/RecorderManager.js',
      'sidepanel/auth/AuthState.js',
      'sidepanel/auth/AuthAPI.js',
      'sidepanel/auth/AuthStorage.js',
      'sidepanel/ExtensionUI.js',
      'sidepanel/ExtensionAuth.js', 
      'sidepanel/ExtensionMain.js'
    ];

    for (const module of modules) {
      console.log(`🔄 CARREGANDO MÓDULO: ${module}`);
      await loadScript(module);
      console.log(`✅ MÓDULO CARREGADO: ${module}`);
    }

    console.log('🚀 TODOS OS MÓDULOS CARREGADOS, inicializando extensão...');
    
    // IMPORTANTE: Sempre mostrar login primeiro, mesmo após carregar módulos
    console.log('🔒 REFORÇANDO exibição da tela de login após carregar módulos...');
    await forceLoginScreenImmediately();
    
    // Aguardar um pouco mais para garantir que a UI foi renderizada
    setTimeout(() => {
      console.log('🎯 INICIALIZANDO o coordenador principal da extensão...');
      // Verificar se ExtensionMain existe antes de instanciar
      if (typeof ExtensionMain !== 'undefined') {
        new ExtensionMain();
      } else {
        console.error('❌ ExtensionMain não está disponível!');
      }
    }, 500);
    
  } catch (error) {
    console.error('💥 ERRO ao carregar módulos da extensão:', error);
    // Mesmo com erro, garantir que login está visível
    await forceLoginScreenImmediately();
  }
}

function loadScript(src) {
  return new Promise((resolve, reject) => {
    // Verificar se o script já foi carregado
    if (document.querySelector(`script[src="${src}"]`)) {
      console.log(`⚠️ SCRIPT já carregado: ${src}`);
      resolve();
      return;
    }
    
    const script = document.createElement('script');
    script.src = src;
    script.onload = () => {
      console.log(`📁 SCRIPT carregado com sucesso: ${src}`);
      resolve();
    };
    script.onerror = (error) => {
      console.error(`❌ ERRO ao carregar script: ${src}`, error);
      reject(error);
    };
    document.head.appendChild(script);
  });
}

// Aguardar elementos existirem antes de inicializar
async function initialize() {
  console.log('🎬 EXTENSION-SIDEPANEL: Aguardando elementos e inicializando...');
  
  await waitForElements();
  await forceLoginScreenImmediately();
  
  setTimeout(() => {
    loadExtensionModules();
  }, 100);
}

// Inicializar
initialize();

console.log('🔒 === EXTENSION SIDEPANEL CONFIGURADO PARA SEMPRE MOSTRAR LOGIN PRIMEIRO - VERSÃO FINAL ===');
