
import { EventHandlers } from './EventHandlers.js';
import { ElementUtils } from './ElementUtils.js';
import { UIHelpers } from './UIHelpers.js';
import { StepRecorder } from './StepRecorder.js';

export class TestRecorder {
  constructor() {
    this.isRecording = false;
    this.assertMode = false;
    this.currentUrl = window.location.href;
    this.steps = [];
    this.highlightedElement = null;
    this.overlay = null;
    this.isProcessingAssert = false;
    
    // Initialize helper modules
    this.elementUtils = new ElementUtils();
    this.uiHelpers = new UIHelpers();
    this.stepRecorder = new StepRecorder();
    this.eventHandlers = new EventHandlers(this);
    
    this.initializeRecorder();
    this.setupMessageListener();
    this.setupNavigationDetection();
  }

  initializeRecorder() {
    console.log('QA Test Recorder: Content script loaded');
    this.uiHelpers.createOverlay();
    this.overlay = this.uiHelpers.overlay;
  }

  setupMessageListener() {
    chrome.runtime.onMessage.addListener((message) => {
      if (message.type === 'startRecording') {
        this.startRecording(message.assertMode);
      } else if (message.type === 'stopRecording') {
        this.stopRecording();
      } else if (message.type === 'updateAssertMode') {
        this.assertMode = message.assertMode;
      }
    });
  }

  startRecording(assertMode) {
    this.isRecording = true;
    this.assertMode = assertMode || false;
    this.steps = [];
    this.currentUrl = window.location.href;
    this.eventHandlers.attachEventListeners();
    this.uiHelpers.updateOverlay(true);
    console.log('🚀 Recording started!');
  }

  stopRecording() {
    this.isRecording = false;
    this.assertMode = false;
    this.eventHandlers.removeEventListeners();
    this.uiHelpers.clearHighlight();
    this.uiHelpers.updateOverlay(false);
    this.isProcessingAssert = false;
    console.log('🛑 Recording stopped!');
  }

  recordStep(step) {
    this.stepRecorder.recordStep(step);
  }

  isRecorderElement(element) {
    return element.id === 'qa-test-recorder-overlay' || 
           element.closest('#qa-test-recorder-overlay');
  }

  setupNavigationDetection() {
    // Monitorar navegação e alterações de rota SPA
    let lastUrl = location.href;
    new MutationObserver(() => {
      const url = location.href;
      if (url !== lastUrl) {
        lastUrl = url;
        console.log('🌐 Page navigated to:', url);
        
        if (this.isRecording) {
          // Verificar se a navegação aconteceu logo após um clique que pode causar navegação
          const timeSinceLastClick = Date.now() - this.eventHandlers.lastClickTime;
          const shouldSkipNavigation = this.eventHandlers.lastClickWasNavigation && timeSinceLastClick < 3000;
          
          if (!shouldSkipNavigation) {
            console.log('📝 Recording navigation step');
            this.recordStep({
              type: 'navigate',
              url: url,
              from: this.currentUrl
            });
          } else {
            console.log('🚫 Skipping navigation step - caused by previous click');
          }
          
          this.currentUrl = url;
        }
      }
    }).observe(document, { subtree: true, childList: true });
  }
}
