
export class UIHelpers {
  constructor() {
    this.overlay = null;
    this.highlightedElement = null;
    this.originalBackgroundColor = null;
    this.originalOutline = null;
  }

  createOverlay() {
    this.overlay = document.createElement('div');
    this.overlay.id = 'qa-test-recorder-overlay';
    this.overlay.style.cssText = `
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.1);
      pointer-events: none;
      z-index: 10000;
      display: none;
    `;
    document.body.appendChild(this.overlay);
  }

  updateOverlay(show) {
    if (this.overlay) {
      this.overlay.style.display = show ? 'block' : 'none';
    }
  }

  highlightElement(element, color) {
    if (this.highlightedElement && this.highlightedElement !== element) {
      this.clearHighlight();
    }

    this.highlightedElement = element;
    this.originalBackgroundColor = element.style.backgroundColor;
    this.originalOutline = element.style.outline;
    element.style.backgroundColor = color;
    element.style.outline = '2px solid #ffeb3b';
  }

  clearHighlight() {
    if (this.highlightedElement) {
      this.highlightedElement.style.backgroundColor = this.originalBackgroundColor || '';
      this.highlightedElement.style.outline = this.originalOutline || '';
      this.highlightedElement = null;
    }
  }

  flashElement(element, color) {
    const originalColor = element.style.backgroundColor;
    const originalOutline = element.style.outline;
    
    element.style.backgroundColor = color;
    element.style.outline = `2px solid ${color}`;
    
    setTimeout(() => {
      element.style.backgroundColor = originalColor;
      element.style.outline = originalOutline;
    }, 300);
  }
}
