export class EventHandlers {
  constructor(recorder) {
    this.recorder = recorder;
    this.scrollTimeout = null;
    this.lastScrollY = window.scrollY;
    this.lastClickTime = 0;
    this.lastClickWasNavigation = false;
    this.lastClickedElement = null;
    this.lastClickSelector = null;
    this.clickDebounceTime = 1000;
    this.recentClicks = new Set();
    this.processingClick = false;
    this.navigationClicks = new Set();
  }

  attachEventListeners() {
    document.addEventListener('click', this.handleClick.bind(this), true);
    document.addEventListener('input', this.handleInput.bind(this), true);
    document.addEventListener('change', this.handleChange.bind(this), true);
    document.addEventListener('scroll', this.handleScroll.bind(this), true);
    document.addEventListener('mouseover', this.handleMouseOver.bind(this), true);
    document.addEventListener('mouseout', this.handleMouseOut.bind(this), true);
    document.addEventListener('keydown', this.handleKeydown.bind(this), true);
  }

  removeEventListeners() {
    document.removeEventListener('click', this.handleClick.bind(this), true);
    document.removeEventListener('input', this.handleInput.bind(this), true);
    document.removeEventListener('change', this.handleChange.bind(this), true);
    document.removeEventListener('scroll', this.handleScroll.bind(this), true);
    document.removeEventListener('mouseover', this.handleMouseOver.bind(this), true);
    document.removeEventListener('mouseout', this.handleMouseOut.bind(this), true);
    document.removeEventListener('keydown', this.handleKeydown.bind(this), true);
  }

  handleClick(event) {
    if (!this.recorder.isRecording || this.recorder.isRecorderElement(event.target)) return;

    if (this.processingClick) {
      console.log('🚫 Skipping click - already processing another click');
      return;
    }

    this.processingClick = true;

    try {
      const currentTime = Date.now();
      const selector = this.recorder.elementUtils.getElementSelector(event.target);
      const elementInfo = this.recorder.elementUtils.getElementInfo(event.target);
      
      // Criar chave única para debounce
      const clickKey = `${selector}:${elementInfo.text}:${Math.floor(currentTime / 500)}`;
      
      if (this.recentClicks.has(clickKey)) {
        console.log('🚫 Skipping duplicate click - element clicked recently');
        console.log(`Element: ${selector}, Text: ${elementInfo.text}`);
        return;
      }

      if (this.recorder.assertMode) {
        event.preventDefault();
        event.stopPropagation();
        event.stopImmediatePropagation();
        
        if (this.recorder.isProcessingAssert) return;
        
        this.handleAssert(event.target);
        return;
      }

      // Verificar se o clique pode causar navegação
      const willNavigate = this.willElementCauseNavigation(event.target);

      console.log(`🔗 Recording click on element: ${selector}, willNavigate: ${willNavigate}`);

      // Adicionar à lista de cliques recentes
      this.recentClicks.add(clickKey);
      setTimeout(() => {
        this.recentClicks.delete(clickKey);
      }, this.clickDebounceTime);

      // Se vai causar navegação, marcar para evitar gravação de navegação separada
      if (willNavigate) {
        this.lastClickWasNavigation = true;
        this.lastClickTime = currentTime;
        this.lastClickSelector = selector;
        
        // Notificar background script para evitar múltiplas navegações
        chrome.runtime.sendMessage({
          type: 'navigationClickDetected',
          selector: selector,
          timestamp: currentTime,
          url: window.location.href,
          preventNavigation: true // Flag para prevenir gravação de navegação
        }).catch(() => {
          console.log('Background script not available');
        });
        
        console.log('🔗 Navigation click detected - preventing separate navigation steps');
        
        // Resetar flag após tempo suficiente
        setTimeout(() => {
          this.lastClickWasNavigation = false;
          console.log('🔄 Navigation click flag reset');
        }, 3000);
      }

      // Gravar apenas o step de clique
      this.recorder.recordStep({
        type: 'click',
        selector: selector,
        element: elementInfo.text,
        tagName: event.target.tagName.toLowerCase(),
        x: event.clientX,
        y: event.clientY,
        willNavigate: willNavigate
      });

      this.lastClickTime = currentTime;
      this.lastClickedElement = event.target;
      this.lastClickSelector = selector;

      this.recorder.uiHelpers.flashElement(event.target, '#2196F3');

    } finally {
      setTimeout(() => {
        this.processingClick = false;
      }, 100);
    }
  }

  willElementCauseNavigation(element) {
    // Verificar se é um link
    if (element.tagName.toLowerCase() === 'a') {
      const href = element.getAttribute('href');
      if (href && href.trim() !== '' && !href.startsWith('#') && !href.startsWith('javascript:')) {
        console.log('🔗 Link detected:', href);
        return true;
      }
    }
    
    // Verificar se é um botão que pode submeter um formulário
    if (element.tagName.toLowerCase() === 'button' && element.type === 'submit') {
      console.log('📝 Submit button detected');
      return true;
    }
    
    // Verificar se tem onclick que pode causar navegação
    if (element.onclick || element.getAttribute('onclick')) {
      const onclickStr = element.onclick ? element.onclick.toString() : element.getAttribute('onclick');
      if (onclickStr.includes('location') || onclickStr.includes('href') || onclickStr.includes('navigate')) {
        console.log('🔗 Navigation onclick detected');
        return true;
      }
    }
    
    // Verificar se está dentro de um link
    const parentLink = element.closest('a[href]');
    if (parentLink) {
      const href = parentLink.getAttribute('href');
      if (href && href.trim() !== '' && !href.startsWith('#') && !href.startsWith('javascript:')) {
        console.log('🔗 Parent link detected:', href);
        return true;
      }
    }
    
    return false;
  }

  handleInput(event) {
    if (!this.recorder.isRecording || this.recorder.isRecorderElement(event.target)) return;

    const selector = this.recorder.elementUtils.getElementSelector(event.target);
    const elementInfo = this.recorder.elementUtils.getElementInfo(event.target);

    this.recorder.recordStep({
      type: 'type',
      selector: selector,
      element: elementInfo.text,
      tagName: event.target.tagName.toLowerCase(),
      value: event.target.value,
      text: event.target.value
    });

    this.recorder.uiHelpers.flashElement(event.target, '#FF9800');
  }

  handleChange(event) {
    if (!this.recorder.isRecording || this.recorder.isRecorderElement(event.target)) return;

    const selector = this.recorder.elementUtils.getElementSelector(event.target);
    const elementInfo = this.recorder.elementUtils.getElementInfo(event.target);

    if (event.target.type === 'checkbox' || event.target.type === 'radio') {
      this.recorder.recordStep({
        type: event.target.type === 'checkbox' ? 'check' : 'radio',
        selector: selector,
        element: elementInfo.text,
        tagName: event.target.tagName.toLowerCase(),
        checked: event.target.checked,
        value: event.target.value
      });
    } else if (event.target.tagName.toLowerCase() === 'select') {
      this.recorder.recordStep({
        type: 'select',
        selector: selector,
        element: elementInfo.text,
        tagName: event.target.tagName.toLowerCase(),
        value: event.target.value,
        text: event.target.options[event.target.selectedIndex]?.text
      });
    }

    this.recorder.uiHelpers.flashElement(event.target, '#9C27B0');
  }

  handleScroll(event) {
    if (!this.recorder.isRecording) return;

    clearTimeout(this.scrollTimeout);
    this.scrollTimeout = setTimeout(() => {
      this.recorder.recordStep({
        type: 'scroll',
        x: window.scrollX,
        y: window.scrollY,
        direction: this.lastScrollY < window.scrollY ? 'down' : 'up'
      });
      this.lastScrollY = window.scrollY;
    }, 300);
  }

  handleKeydown(event) {
    if (!this.recorder.isRecording || this.recorder.isRecorderElement(event.target)) return;

    if (event.key === 'Enter' || event.key === 'Tab' || event.key === 'Escape') {
      const selector = this.recorder.elementUtils.getElementSelector(event.target);
      const elementInfo = this.recorder.elementUtils.getElementInfo(event.target);

      this.recorder.recordStep({
        type: 'keypress',
        selector: selector,
        element: elementInfo.text,
        tagName: event.target.tagName.toLowerCase(),
        key: event.key,
        code: event.code
      });

      this.recorder.uiHelpers.flashElement(event.target, '#E91E63');
    }
  }

  handleMouseOver(event) {
    if (!this.recorder.isRecording || this.recorder.isRecorderElement(event.target)) return;
    this.recorder.uiHelpers.highlightElement(event.target, 'rgba(255, 255, 0, 0.3)');
  }

  handleMouseOut(event) {
    if (!this.recorder.isRecording) return;
    this.recorder.uiHelpers.clearHighlight(event.target);
  }

  handleAssert(element) {
    if (this.recorder.isProcessingAssert) return;
    this.recorder.isProcessingAssert = true;

    try {
      const selector = this.recorder.elementUtils.getElementSelector(element);
      const elementInfo = this.recorder.elementUtils.getElementInfo(element);

      const assertionType = prompt(
        `Escolha o tipo de assertion para "${elementInfo.text}":\n\n` +
        '1. exist (elemento existe)\n' +
        '2. visible (elemento visível)\n' +
        '3. contain (contém texto)\n' +
        '4. have.value (tem valor)\n' +
        '5. have.class (tem classe)\n' +
        '6. be.enabled (está habilitado)\n' +
        '7. be.disabled (está desabilitado)\n\n' +
        'Digite o número da opção:'
      );

      if (assertionType === null || assertionType === '') {
        return;
      }

      const assertions = {
        '1': 'exist',
        '2': 'be.visible',
        '3': 'contain',
        '4': 'have.value',
        '5': 'have.class',
        '6': 'be.enabled',
        '7': 'be.disabled'
      };

      const assertion = assertions[assertionType];
      if (assertion) {
        let expectedValue = '';
        
        if (assertion === 'contain' || assertion === 'have.value' || assertion === 'have.class') {
          expectedValue = prompt(`Digite o valor esperado para "${assertion}":`);
          
          if (expectedValue === null) {
            return;
          }
        }

        this.recorder.recordStep({
          type: 'assert',
          selector: selector,
          assertion: assertion,
          expectedValue: expectedValue,
          element: elementInfo.text
        });

        this.recorder.uiHelpers.flashElement(element, '#4CAF50');
      }
    } finally {
      setTimeout(() => {
        this.recorder.isProcessingAssert = false;
      }, 100);
    }
  }
}
