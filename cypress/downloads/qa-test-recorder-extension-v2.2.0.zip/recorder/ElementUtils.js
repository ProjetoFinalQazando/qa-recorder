
export class ElementUtils {
  getElementSelector(element) {
    if (element.id) {
      return `#${element.id}`;
    }
    
    if (element.getAttribute('data-testid')) {
      return `[data-testid="${element.getAttribute('data-testid')}"]`;
    }

    if (element.classList && element.classList.length > 0) {
      const classes = Array.from(element.classList).join('.');
      const classSelector = `.${classes}`;
      
      if (document.querySelectorAll(classSelector).length === 1) {
        return classSelector;
      }
    }

    if (element.name) {
      return `[name="${element.name}"]`;
    }

    if (element.getAttribute('aria-label')) {
      return `[aria-label="${element.getAttribute('aria-label')}"]`;
    }

    const parent = element.parentElement;
    if (parent) {
      const siblings = Array.from(parent.children);
      const index = siblings.indexOf(element) + 1;
      const parentSelector = this.getElementSelector(parent);
      return `${parentSelector} > ${element.tagName.toLowerCase()}:nth-child(${index})`;
    }

    return element.tagName.toLowerCase();
  }

  getElementInfo(element) {
    let text = '';
    
    if (element.textContent && element.textContent.trim()) {
      text = element.textContent.trim().substring(0, 30);
    } else if (element.placeholder) {
      text = `placeholder: ${element.placeholder}`;
    } else if (element.title) {
      text = `title: ${element.title}`;
    } else if (element.alt) {
      text = `alt: ${element.alt}`;
    } else if (element.value && element.type !== 'password') {
      text = `value: ${element.value}`;
    } else if (element.getAttribute('aria-label')) {
      text = `aria-label: ${element.getAttribute('aria-label')}`;
    } else {
      text = element.tagName.toLowerCase();
    }

    return { text: text || 'elemento' };
  }
}
