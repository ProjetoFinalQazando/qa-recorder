
export class StepRecorder {
  recordStep(step) {
    step.url = window.location.href;
    step.timestamp = Date.now();
    step.id = this.generateId();

    chrome.runtime.sendMessage({
      type: 'stepRecorded',
      step: step
    }).catch(error => {
      console.log('Error sending step to background:', error);
    });

    console.log('Step recorded:', step);
  }

  generateId() {
    return Math.random().toString(36).substr(2, 9);
  }
}
